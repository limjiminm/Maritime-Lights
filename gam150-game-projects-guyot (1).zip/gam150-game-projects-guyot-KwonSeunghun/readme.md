# Spring 2023 GAM150 Team Guyot - Maritime Lights
- - - -
## Team Members
### Seunghun Kwon
	Technical lead / Gameplay Lead / Developer
	Was responsible for:
		* Implementation of game object: Portal
		* Stage design: Stages 3, 4
		* Stage implementation: Stages 3, 4
		* Game-related documentations: Weekly Reports, Game Design Document
		* Primary contributor to code merging & conflict resolution
		* All code related to audio

### Bada Kim
	Lead Visual Designer / Artist / Developer
	Was responsible for:
		* Character design: All in-game characters & game objects
		* All art assets
		* All SPT and ANM files
		* Tutorial, menu, credits image
		* Stage design: Stages 7 and 8
		* Game-related documentations: Weekly Reports

### Minseo Park
	Lead Audio Designer / Developer
	Was responsible for:
		* Creation of background music & sound effect assets
		* Game-related documentations: Weekly Reports

### Hankyung Lee
	Producer / Physics Programmer / Developer
	Was responsible for:
		* Game design: concept, game object mechanisms, objectives
		* Implementation of game objects: Bulbpuf, Nemo, Anemone, Charger, Tile, Wall, Footprint, Urchin
		* All physics and AI of game objects
		* Implementation of game state component: MapManager
		* Stage design: Stage 1
		* Game-related documentations: Weekly Reports, Technical Guide, Game Design Document

### Jimin Lim
	Test Lead / Level Designer / Developer
	Was responsible for: 
		* Stage design: Stages 2, 5, 6
		* Stage implementation: Stages 2, 5, 6, 7, 8
		* Scene implementation: Main menu, Tutorial, Credits
		* Game-related documentations: Weekly Reports, Game Design Document
		* Assisted in code merging & conflict resolution

- - - -
## Compilation Instructions	
	Open the `GAM150demorefactor.sln` file in Visual Studio, and compile.
	Make sure the Assets folder and the following files are in the same folder as the executable:
```
openal32.dll
sfml-audio-2.dll
sfml-audio.lib
sfml-main.lib
sfml-system-2.dll
sfml-system.lib
```
- - - -
## About the Game
	Maritime Lights is an adventure-puzzle game where you explore the deep sea and interact with various sea critters. You beat the game by going through all 8 stages. 
- - - -
## How to Play
	Your character will follow your mouse around the screen. Move around by moving your cursor to where you want to go. 
	An area around you will be illuminated by your light; press the right click button to open up the color wheel, and change the light’s color. You can switch to red, green, or blue by releasing your mouse at the corresponding areas of the wheel; you can also go back to white by releasing your mouse anywhere outside of the wheel. 
	You can interact with different objects in the game by using your light. Press on “Tutorial” in the main menu screen to see details on how to interact with each type of game object.
	