//---------------------------------------------------------
// File:	WinMain
// Author:	Jonathan Holmes
//
// Copyright (C) 2021 DigiPen, All rights reserved.
//---------------------------------------------------------

#ifndef BALL_H
#define BALL_H

#include <doodle/doodle.hpp>
using namespace doodle;
#include "soundeffect.h"

constexpr double gravity = 9.8;

class Ball {
public:
    Ball(double _x, double _y, double _x_velocity, double _y_velocity, double _size);
    void draw();
    void check_collision(Ball other);
    void apply_physics();
    SoundEffect* sound_side = nullptr;
    SoundEffect* sound_ground = nullptr;

private:
    double   x = 0;
    double   y = 0;
    double   x_velocity = 0;
    double   y_velocity = 0;
    double   size = 40;
    double   bounciness = 0.5;
    HexColor color = { 0xff0f0fff };
    double   radius();
};

#endif
