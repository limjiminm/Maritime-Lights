//---------------------------------------------------------
// File:	WinMain
// Author:	Jonathan Holmes
//
// Copyright (C) 2021 DigiPen, All rights reserved.
//---------------------------------------------------------

#include "soundeffect.h"

SoundEffect::SoundEffect(const string& filename) {
    if(!buffer.loadFromFile(filename)) {
        cout << "Failed to load the music file: " << filename << endl;
    }
}

void SoundEffect::play() {
    sound.setBuffer(buffer);
    sound.play();
}