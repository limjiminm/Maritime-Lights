//---------------------------------------------------------
// File:	WinMain
// Author:	Jonathan Holmes
//
// Copyright (C) 2021 DigiPen, All rights reserved.
//---------------------------------------------------------

#include <SFML/Audio.hpp>
#include <doodle/doodle.hpp>

#include <iostream>
#include <string>
#include <vector>
using namespace std;
using namespace doodle;
using namespace sf;

#include "ball.h"
#include "soundeffect.h"

#define SFX_A 0
#define SFX_B 1
#define SFX_C 2
#define SFX_D 3
SoundEffect sound_effects[] = {
    SoundEffect("assets/Piano/a.wav"),
    SoundEffect("assets/Piano/b.wav"),
    SoundEffect("assets/Piano/c.wav"),
    SoundEffect("assets/Piano/d.wav"),
};

Music background_music;

void setup() {
    create_window(800, 800);
    set_outline_width(3.0);

    set_frame_of_reference(FrameOfReference::LeftHanded_OriginTopLeft);

    if(!background_music.openFromFile("assets/orchestral.ogg")) {
        cout << "Failed to load the music file: assets/orchestral.ogg" << endl;
    }

    background_music.setLoop(true);
    background_music.setVolume(50.0);
    background_music.play();
}

vector<Ball> balls;
bool         not_clicked = false;

void gameplay() {
    if(!MouseIsPressed) {
        not_clicked = true;
    }

    if(MouseIsPressed && not_clicked == true) {
        sound_effects[SFX_C].play();
        Ball ball = Ball(
            random(0.0, double(Width)),  // x
            random(0.0, double(Height)), // y
            random(-20.0, 20.0),         // x_velocity
            random(-20.0, 20.0),         // y_velocity
            random(10.0, 50.0)           // size441
        );
        ball.sound_ground = &sound_effects[SFX_A];
        ball.sound_side = &sound_effects[SFX_D];
        balls.push_back(ball);
        not_clicked = false;
    }

    for(int i = 0; i < balls.size(); i++) {
        for(int o = 0; o < balls.size(); o++) {
            if(o == i) {
                continue;
            }
            balls[i].check_collision(balls[o]);
        }
    }

    for(int i = 0; i < balls.size(); i++) {
        balls[i].apply_physics();
        balls[i].draw();
    }
}

int main() {
    try {
        setup();

        while(!is_window_closed()) {
            update_window();
            clear_background(255);
            gameplay();
        }
    } catch(std::exception& e) {
        std::cerr << e.what() << "\n";
        return -1;
    }
}
