//---------------------------------------------------------
// File:	WinMain
// Author:	Jonathan Holmes
//
// Copyright (C) 2021 DigiPen, All rights reserved.
//---------------------------------------------------------

#include "ball.h"

Ball::Ball(double _x, double _y, double _x_velocity, double _y_velocity, double _size) {
    x = _x;
    y = _y;
    x_velocity = _x_velocity;
    y_velocity = _y_velocity;
    size = _size;
}

double Ball::radius() {
    double radius = size / 2;
    return radius;
}

void Ball::draw() {
    set_fill_color(color);
    draw_ellipse(x, y, size, size);
}

void Ball::check_collision(Ball other) {
    double a = other.x - x;
    double b = other.y - y;
    double distance = sqrt(a * a + b * b);
    if(distance < other.radius() + radius()) {
        //y_velocity = y_velocity * 0.9;
        x_velocity = x_velocity * 0.975;
    }
}

void Ball::apply_physics() {
    y_velocity += gravity * DeltaTime;

    if(x_velocity > 0) {
        x_velocity -= 0.1 * DeltaTime;
    } else if(x_velocity < 0) {
        x_velocity += 0.1 * DeltaTime;
    }

    x += x_velocity;
    y += y_velocity;

    if(y > Height - size / 2) {
        y = Height - size / 2;
        y_velocity = 0 - y_velocity * bounciness;

        if(y_velocity < -1.0) {
            if(sound_ground != nullptr) {
                sound_ground->play();
            }
        }
    }

    if(x < size / 2) {
        if(sound_side != nullptr) {
            sound_side->play();
        }
        x = size / 2;
        x_velocity = 0 - x_velocity * bounciness;
    }
    if(x > Width - size / 2) {
        if(sound_side != nullptr) {
            sound_side->play();
        }
        x = Width - size / 2;
        x_velocity = 0 - x_velocity * bounciness;
    }
}