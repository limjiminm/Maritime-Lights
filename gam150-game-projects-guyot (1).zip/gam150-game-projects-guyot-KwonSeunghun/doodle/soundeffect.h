//---------------------------------------------------------
// File:	WinMain
// Author:	Jonathan Holmes
//
// Copyright (C) 2021 DigiPen, All rights reserved.
//---------------------------------------------------------

#ifndef SOUNDEFFECT_H
#define SOUNDEFFECT_H

#include <SFML/Audio.hpp>
#include <string>
#include <iostream>
using namespace sf;
using namespace std;

class SoundEffect {
public:
    SoundEffect(const string& filename);
    SoundBuffer buffer;
    Sound       sound;
    void        play();
};
#endif