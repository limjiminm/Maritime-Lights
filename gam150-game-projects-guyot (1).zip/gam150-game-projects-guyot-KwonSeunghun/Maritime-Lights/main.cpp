/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  main.cpp
Project:    CS230 Engine
Author:     Jonathan Holmes, Hankyung Lee, Seunghun Kwon, Bada Kim, Jimin Lim, Minseo Park
Created:    March 8, 2023
Updated:    April 15, 2023
*/

#include <iostream>
#include "Engine/Engine.h"
#include <SFML/Audio.hpp>
#include "Engine/NoResize.h"
#include "Engine/soundeffect.h"
#include "Game/Splash.h"
#include "Game/Menu.h"
#include "Game/Tutorial.h"
#include "Game/Credits.h"
#include "Game/Tutorial1.h"
#include "Game/Tutorial2.h"
#include "Game/Tutorial3.h"
#include "Game/Tutorial4.h"
#include "Game/Nemo1.h"
#include "Game/Nemo2.h"
#include "Game/Tile1.h"
#include "Game/Tile2.h"
#include "Game/Maze.h"
#include "Game/UrchinNemo1.h"
#include "Game/UrchinNemo2.h"
#include "Game/Mix1.h"
#include "Game/Mix2.h"
#include "Game/Ending.h"
using namespace sf;

Music background_music;

int main() {

    if (!background_music.openFromFile("Assets/background.ogg")) {
        return -1;
    }

    background_music.setLoop(true);
    background_music.setVolume(20.0);
    background_music.play();


    try {




        Engine& engine = Engine::Instance();
        engine.Start("Maritime Lights");

        Splash splash;
        engine.GetGameStateManager().AddGameState(splash);
        Menu menu;
        engine.GetGameStateManager().AddGameState(menu);
        Tutorial tutorial;
        engine.GetGameStateManager().AddGameState(tutorial);
        Tutorial1 tutorial1;
        engine.GetGameStateManager().AddGameState(tutorial1);
        Tutorial2 tutorial2;
        engine.GetGameStateManager().AddGameState(tutorial2);
        Tutorial3 tutorial3;
        engine.GetGameStateManager().AddGameState(tutorial3);
        Tutorial4 tutorial4;
        engine.GetGameStateManager().AddGameState(tutorial4);
        Credits credits;
        engine.GetGameStateManager().AddGameState(credits);
        Nemo1 nemo1;
        engine.GetGameStateManager().AddGameState(nemo1);
        Nemo2 nemo2;
        engine.GetGameStateManager().AddGameState(nemo2);
        Tile1 tile1;
        engine.GetGameStateManager().AddGameState(tile1);
        Tile2 tile2;
        engine.GetGameStateManager().AddGameState(tile2);
        Maze maze;
        engine.GetGameStateManager().AddGameState(maze);
        UrchinNemo1 urchinnemo1;
        engine.GetGameStateManager().AddGameState(urchinnemo1);
        UrchinNemo2 urchinnemo2;
        engine.GetGameStateManager().AddGameState(urchinnemo2);
        Mix1 mix1;
        engine.GetGameStateManager().AddGameState(mix1);
        Mix2 mix2;
        engine.GetGameStateManager().AddGameState(mix2);
        Ending ending;
        engine.GetGameStateManager().AddGameState(ending);

        make_window_not_resizable();


        while(engine.HasGameEnded() == false) {
            engine.Update();
        }

        engine.Stop();


        return 0;
    } catch(std::exception& e) {
        std::cerr << e.what() << "\n";
        return -1;
    }   
}

