/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Tile2.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#pragma once
#include "../Engine/Camera.h"
#include "../Engine/GameObjectManager.h"
#include "../Engine/GameState.h"
#include "../Engine/Sprite.h"
#include "../Engine/Vec2.h"

class Bulbpuf;

class Tile2 : public CS230::GameState {
public:
    Tile2();
    void Load() override;
    void Update(double dt) override;
    void Unload() override;
    void Draw() override;

    std::string GetName() override { return "Tile2"; }

private:
    Bulbpuf* bulbpuf_ptr;
};