/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Clam.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 3, 2023
Updated:    May 8, 2023
*/

#include "Clam.h"
#include "..\Maritime-Lights\Game\Bulbpuf.h"
#include "Laser.h"
//#include <doodle/doodle.hpp>
//using namespace doodle;

Clam::Clam(Math::vec2 position, Math::vec2 scale) :
	GameObject(position, GetRotation(), scale)
{
	current_state = &state_out;
	sprite.Load("Assets/Clam.spt");
	SetVelocity({ 0,0 });
	SetPosition(position);
}

Clam::~Clam()
{


}

void Clam::Update(double dt)
{
	GameObject::Update(dt);
	if (current_state == &state_in) {
		UpdatePosition({ GetVelocity().x, GetVelocity().y });
	}
}

void Clam::State_In::Enter(GameObject* object)
{
	Clam* clam = static_cast<Clam*>(object);
	//clam->sprite.PlayAnimation(static_cast<int>(Animations::In));
}
void Clam::State_In::Update(GameObject* object, double dt)
{
	Clam* clam = static_cast<Clam*>(object);
	Bulbpuf* bulbpubp = static_cast<Bulbpuf*>(object);
	//draw_ellipse(500, 500, 50, 50);
	bulbpubp->SetPosition(clam->GetPosition());
}

void Clam::State_In::CheckExit(GameObject* object)
{
	Clam* clam = static_cast<Clam*>(object);
	//if (��ġ�� �������, ��Ŭ�� ������)
	//	clam->change_state(&clam->state_in);

}

void Clam::State_Out::Enter(GameObject* object)
{
	Clam* clam = static_cast<Clam*>(object);
	//clam->sprite.PlayAnimation(static_cast<int>(Animations::Out));
}
void Clam::State_Out::Update(GameObject* object, double dt)
{
	Clam* clam = static_cast<Clam*>(object);
	//draw_ellipse(550, 550, 70, 70);
	//��� ����
}

void Clam::State_Out::CheckExit(GameObject* object)
{
	Clam* clam = static_cast<Clam*>(object);
	Bulbpuf* bulbpubp = static_cast<Bulbpuf*>(object);
	double dist_x = clam->GetPosition().x - bulbpubp->GetPosition().x / 2;
	double dist_y = clam->GetPosition().y - bulbpubp->GetPosition().y / 2;

	if (dist_x <= (double)clam->sprite.GetFrameSize().x / 2 &&
		dist_y <= (double)clam->sprite.GetFrameSize().y / 2) {
		clam->change_state(&clam->state_in);
	}

}