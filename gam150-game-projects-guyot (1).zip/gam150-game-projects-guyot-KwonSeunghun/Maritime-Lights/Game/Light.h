/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Light.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 4, 2022
Updated:    May 4, 2023
*/

#pragma once
#include <vector>
#include "..\Engine\Camera.h"
#include "..\Engine\GameObject.h"
#include "..\Engine\Matrix.h"
#include "LightColors.h"
#include "ColorWheel.h"
#include "GameObjectTypes.h"

class Light : public CS230::GameObject {
    friend class Bulbpuf;
    friend class ColorWheel;
public:
    Light(Math::vec2 start_position);
    ~Light();
    void Draw(Math::TransformationMatrix camera_matrix) override;
    void Update(double dt) override;

    const int GetSize() { return size; }
    std::vector<bool>* GetLightColors() { return &lightcolors; }
    LightColors GetCurrentLightColor();
    void SetLightColor(LightColors color, bool value);

private:
    static constexpr int size = 400;
    std::vector<bool> lightcolors; 
    unsigned char doodlecolor_red = 255;
    unsigned char doodlecolor_green = 255;
    unsigned char doodlecolor_blue = 255;

    void UpdateDoodleColor();
};
