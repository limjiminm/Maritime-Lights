/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  ColorWheel.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 6, 2022
Updated:    May 6, 2023
*/

#pragma once
#include <vector>
#include "..\Engine\Camera.h"
#include "..\Engine\GameObject.h"
#include "..\Engine\Input.h"
#include "..\Engine\Matrix.h"
#include "LightColors.h"

class Bulbpuf;

class ColorWheel : public CS230::GameObject {
    friend class Bulbpuf;
public:
    ColorWheel(Math::vec2 start_position);
    void Update(double dt) override;
    void Draw(Math::TransformationMatrix camera_matrix) override;
    void SetIsActive(bool value) { is_active = value; }

private:
    bool is_active; // toggled in bulbpuf update, check this value before colorwheel::update and draw
    int size = 200;
    std::vector<bool> available_lightcolors;
};
