
/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Clam.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 3, 2023
Updated:    May 4, 2023
*/

#include "..\Engine\GameObject.h"
#include "..\Engine\Matrix.h"
#include "Bulbpuf.h"


class Clam : public CS230::GameObject {
public:
    Clam(Math::vec2 position, Math::vec2 scale);
    ~Clam();
    void Update(double dt) override;
private:

    class State_In : public State {
    public:
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "In"; }
    };
    class State_Out : public State {
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "Out"; }
    };
    State_In state_in;
    State_Out state_out;

    //bool with_bulbpubp = false;

    enum class Animations {
        In, Out
    };
    friend class Bulbpuf;

};