/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Bulbpuf.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 1, 2022
Updated:    May 2, 2023
*/

#pragma once
#include "..\Engine\Camera.h"
#include "..\Engine\GameObject.h"
#include "..\Engine\Input.h"
#include "..\Engine\Matrix.h"
#include "Light.h"
#include "ColorWheel.h"
#include "GameObjectTypes.h"

class Bulbpuf : public CS230::GameObject {
    friend class ColorWheel;
    friend class Light;
public:
    Bulbpuf(Math::vec2 start_position);
    void Update(double dt) override;
    Math::vec2 GetCameraPosition();
    bool MapCollision(double dt);
    void UrchinCollision(double dt);
    bool MapCollision();
    //std::string GetType() override { return "Bulbpuf"; }


protected:

private:
    Math::vec2 previous_position{};
    int size = 75;
    static constexpr int min_distance = 0; // unneeded?
    static constexpr int stop_moving_distance = 5;

    Math::vec2 speed_before_pause = { 0, 0 };

    Math::vec2 urchin_vector{};
    bool urchined = false;
    double urchined_timer = 0;
    double max_urchined_timer = 1.0;

    // Animation files need to be written
    enum class Animations {
        Slow,
        Moving,
        SlowRed,
        SlowGreen,
        SlowBlue,
        MovingRed,
        MovingGreen,
        MovingBlue,
        Urchined,
        UrchinedRed,
        UrchinedGreen,
        UrchinedBlue
    };

    void UpdatePosition(double dt);
    double GetMouseDistance();

    // collision between objects?

    class State_Slow : public State {
    public:
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "Slow"; }
    };

    State_Slow state_slow;

    class State_Moving : public State {
    public:
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "Moving"; }
    };

    State_Moving state_moving;

    class State_Changing_Color : public State {
    public:
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "Changing_Color"; }
    };

    State_Changing_Color state_changing_color;

    class State_Urchined : public State {
    public:
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "Electrocuted"; }
    };

    State_Urchined state_urchined;



};