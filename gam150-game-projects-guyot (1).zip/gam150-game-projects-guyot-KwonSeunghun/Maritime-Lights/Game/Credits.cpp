/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Menu.cpp
Project:    CS230 Engine
Author:     Jonathan Holmes , Jimin Lim(jimin.lim@digipen.edu)
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#include "../Engine/Engine.h"
#include "States.h"
#include "Credits.h"
#include "../Engine/Input.h"
#include "doodle/drawing.hpp"
#include "Background.h"

Credits::Credits() {}

void Credits::Load()
{};

void Credits::Unload()
{}

void Credits::Update(double dt)
{
    if (Engine::GetInput().GetMousePosition().x > 1000 && Engine::GetInput().GetMousePosition().x < 1000 + 137 && Engine::GetInput().GetMousePosition().y > 45 && Engine::GetInput().GetMousePosition().y < 45 + 77 && Engine::GetInput().GetMousePosition().y < 147 && Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == true)
    {
        //Exit_butt
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Menu));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }
}

void Credits::Draw()
{

    Credits_image = Engine::GetTextureManager().Load("Assets/Credits_image.png");
    Credits_image->Draw(Math::TranslationMatrix{ Math::vec2{0,0} });

    Exit_off = Engine::GetTextureManager().Load("Assets/Exit_off.png"); //137 x 77
    Exit_off->Draw(Math::TranslationMatrix{ Math::vec2{1000,45} });

    if (Engine::GetInput().GetMousePosition().x > 1000 && Engine::GetInput().GetMousePosition().x < 1000 + 137 && Engine::GetInput().GetMousePosition().y > 45 && Engine::GetInput().GetMousePosition().y < 45 + 77)
    {
        Exit_on = Engine::GetTextureManager().Load("Assets/Exit_on.png");
        Exit_on->Draw(Math::TranslationMatrix{ Math::vec2{1000,45} });
    }
}

