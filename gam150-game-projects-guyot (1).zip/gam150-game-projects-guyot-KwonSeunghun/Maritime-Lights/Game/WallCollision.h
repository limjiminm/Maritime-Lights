/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  WallCollision.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 7, 2022
Updated:    May 7, 2023
*/

#include "../Engine/Component.h"
#include "../Engine/GameObject.h"

class WallCollision : public CS230::Component {
public:
    WallCollision(CS230::GameObject& object);
    void Update(double dt) override;
    bool* GetColliding() { return &colliding; }

private:
    CS230::GameObject& object;
    int objectsize;
    bool colliding;
};
