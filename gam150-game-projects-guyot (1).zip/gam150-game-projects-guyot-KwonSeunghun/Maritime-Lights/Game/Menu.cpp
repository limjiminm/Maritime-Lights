/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Menu.cpp
Project:    CS230 Engine
Author:     Jonathan Holmes , Jimin Lim(jimin.lim@digipen.edu)
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#include "../Engine/Engine.h"
#include "States.h"
#include "Menu.h"
#include "../Engine/Input.h"
#include "doodle/drawing.hpp"
#include "../Engine/soundeffect.h"

SoundEffect button = SoundEffect("Assets/button.wav");

Menu::Menu() {}

void Menu::Load() 
{};

void Menu::Unload()
{}

void Menu::Update(double dt)
{
    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 713 && Engine::GetInput().GetMousePosition().y > 380 && Engine::GetInput().GetMousePosition().y < 461 && Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == true)
    {
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Nemo1));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }

    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 771 && Engine::GetInput().GetMousePosition().y > 280 && Engine::GetInput().GetMousePosition().y < 360 && Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == true)
    {
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Tutorial));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }

    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 749 && Engine::GetInput().GetMousePosition().y > 180 && Engine::GetInput().GetMousePosition().y < 261 && Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == true)
    {
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Credits));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }
    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 674 && Engine::GetInput().GetMousePosition().y > 80 && Engine::GetInput().GetMousePosition().y < 151 && Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == true)
    {
        Engine::GetGameStateManager().ClearNextGameState();
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }




}

void Menu::Draw() 
{
    backgrounds = Engine::GetTextureManager().Load("Assets/Menu.png");
    backgrounds->Draw(Math::TranslationMatrix{ Math::vec2{0,0} });

    Title = Engine::GetTextureManager().Load("Assets/Title.png");
    Title ->Draw(Math::TranslationMatrix{ Math::vec2{400,480} });

    Start_off = Engine::GetTextureManager().Load("Assets/Start_off.png");
    Start_off->Draw(Math::TranslationMatrix{ Math::vec2{540,380} });

    Tutorial_off = Engine::GetTextureManager().Load("Assets/Tutorial_off.png");
    Tutorial_off->Draw(Math::TranslationMatrix{ Math::vec2{540,280} });

    Credits_off = Engine::GetTextureManager().Load("Assets/Credits_off.png");
    Credits_off->Draw(Math::TranslationMatrix{ Math::vec2{540,180} });

    Exit_off = Engine::GetTextureManager().Load("Assets/Exit_off.png");
    Exit_off->Draw(Math::TranslationMatrix{ Math::vec2{540,80} });

    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 713 && Engine::GetInput().GetMousePosition().y > 380 && Engine::GetInput().GetMousePosition().y < 461)
    {
        Start_on = Engine::GetTextureManager().Load("Assets/Start_on.png");
        Start_on->Draw(Math::TranslationMatrix{ Math::vec2{540,380} });
    }

    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 771 && Engine::GetInput().GetMousePosition().y > 280 && Engine::GetInput().GetMousePosition().y < 360)
    {
        Tutorial_on = Engine::GetTextureManager().Load("Assets/Tutorial_on.png");
        Tutorial_on->Draw(Math::TranslationMatrix{ Math::vec2{540,280} });
    }

    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 749 && Engine::GetInput().GetMousePosition().y > 180 && Engine::GetInput().GetMousePosition().y < 261)
    {
        Credits_on = Engine::GetTextureManager().Load("Assets/Credits_on.png");
        Credits_on->Draw(Math::TranslationMatrix{ Math::vec2{540,180} });
    }

    if (Engine::GetInput().GetMousePosition().x > 540 && Engine::GetInput().GetMousePosition().x < 674 && Engine::GetInput().GetMousePosition().y > 80 && Engine::GetInput().GetMousePosition().y < 151)
    {
        Exit_on = Engine::GetTextureManager().Load("Assets/Exit_on.png");
        Exit_on->Draw(Math::TranslationMatrix{ Math::vec2{540,80} });
    }
}

