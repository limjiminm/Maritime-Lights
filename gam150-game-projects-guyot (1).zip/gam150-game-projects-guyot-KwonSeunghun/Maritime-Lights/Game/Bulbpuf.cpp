/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Bulbpuf.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 1, 2022
Updated:    May 2, 2023
*/

#include "Bulbpuf.h"
#include "ColorWheel.h"
#include "Wall.h"
#include "../Engine/Collision.h"
#include "../Engine/Engine.h"
#include "../Engine/Vec2.h"
#include "../Engine/Matrix.h"
#include "../Engine/MapManager.h"
#include "../Engine/ShapeMass.h"
#include <doodle/drawing.hpp>
#include <cmath> // for abs
#include "../Engine/soundeffect.h"

SoundEffect urchinsound = SoundEffect("Assets/urchin.wav");


Bulbpuf::Bulbpuf(Math::vec2 start_position) :
	GameObject(start_position)
{
	current_state = &state_moving;
	AddGOComponent(new CS230::Sprite("Assets/Bulbpuf.spt", this));
	SetPosition(start_position);
}

void Bulbpuf::Update(double dt)
{
	previous_position = GetPosition();
	CS230::Sprite* sprite = GetGOComponent<CS230::Sprite>();
	CS230::Camera* camera = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>();

	GameObject::Update(dt);
	UrchinCollision(dt);


	if (MapCollision(dt))
	{
		SetPosition(previous_position);
	}

	// camera boundary check
	if (GetPosition().x < camera->GetPosition().x + sprite->GetFrameSize().x / 2) {
		SetPosition({ camera->GetPosition().x + sprite->GetFrameSize().x / 2, GetPosition().y });
		SetVelocity({ 0, GetVelocity().y });
	}
	if (GetPosition().x + sprite->GetFrameSize().x / 2 > camera->GetPosition().x + Engine::GetWindow().GetSize().x) {
		SetPosition({ camera->GetPosition().x + Engine::GetWindow().GetSize().x - sprite->GetFrameSize().x / 2, GetPosition().y });
		SetVelocity({ 0, GetVelocity().y });
	}
	if (GetPosition().y < camera->GetPosition().y + sprite->GetFrameSize().y / 2) {
		SetPosition({ GetPosition().x, camera->GetPosition().y + sprite->GetFrameSize().y / 2 });
		SetVelocity({ GetVelocity().x, 0 });
	}
	if (GetPosition().y + sprite->GetFrameSize().y / 2 > camera->GetPosition().y + Engine::GetWindow().GetSize().y) {
		SetPosition({ GetPosition().x, camera->GetPosition().y + Engine::GetWindow().GetSize().y - sprite->GetFrameSize().y / 2 });
		SetVelocity({ GetVelocity().x, 0 });
	}

}

/*
Code for sliding collision resolution - discarded because of bug where collision does not happen at each ends of walls
*/
//void Bulbpuf::MapCollision(double dt)
//{
//	Math::vec2 source_position = GetPosition();
//	Math::vec2 position_delta = GetVelocity() * dt;
//	[[maybe_unused]] Math::vec2 destination_position = GetPosition() + position_delta;
//	std::vector<ShapeMass*>* map = Engine::GetGameStateManager().GetGSComponent<CS230::MapManager>()->GetShapeMasses();
//	Math::vec2 camera_position = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>()->GetPosition(); // for drawing test lines, delete later
//
//	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
//	std::vector<Wall*> walls{};
//	for (GameObject* object : *objects)
//	{
//		Wall* wall = dynamic_cast<Wall*>(object);
//		if (wall != nullptr)
//		{
//			walls.push_back(wall);
//		}
//	}
//
//	SetPosition(source_position);
//
//	bool did_collide = false;
//	bool did_passthrough = false;
//	bool too_close = false;
//	Math::vec2 how_close{};
//	for (ShapeMass* mass : *map)
//	{
//		std::vector<Point*>* points = mass->GetPoints();
//		for (int i = 0; i < points->size(); ++i)
//		{
//			Math::vec2 point1 = *(*points)[i]->GetPosition();
//			Math::vec2 point2 = *(*points)[(i + 1) % points->size()]->GetPosition();
//			double line_dx = point2.x - point1.x;
//			double line_dy = point2.y - point1.y;
//			double line_length = sqrt(pow(line_dx, 2) + pow(line_dy, 2));
//			Math::vec2 line_normal = { -line_dy / line_length, line_dx / line_length };
//			double line_angle = Math::angle_between(Math::ANGLE_ZERO, Math::vec2{ line_dx, line_dy });
//
//			// 1. is the player colliding with one of the walls?
//			if (did_collide == false && Collision::CircleLine(&GetPosition(), &size, &point1, &point2) == true)
//			{
//				did_collide = true;
//
//				//Math::vec2 point1_extended = point1 - Math::vec2{size* cos(line_angle), size* sin(line_angle)};
//				//Math::vec2 point2_extended = point2 + Math::vec2{size* cos(line_angle), size* sin(line_angle)};
//
//				position_delta = -line_normal * Math::dot_product(position_delta, line_normal);
//				doodle::push_settings();
//				doodle::set_outline_color(80, 255, 0, 255);
//				doodle::draw_line(point1.x - camera_position.x, point1.y + -camera_position.y, point2.x - camera_position.x, point2.y - camera_position.y);
//				//doodle::draw_line(point1_extended.x - camera_position.x, point1_extended.y + -camera_position.y, point2_extended.x - camera_position.x, point2_extended.y - camera_position.y);
//				doodle::pop_settings();
//				//return;
//			}
//
//			// 2. did the player move so fast that it moved straight through a wall, without colliding with it?
//			if (did_passthrough == false && Collision::LineLine(&point1, &point2, &source_position, &destination_position) == true)
//			{
//				did_passthrough = true;
//			}
//
//			// 3. is the player slightly overlapping with one of the walls?
//			if (too_close == false && Collision::CircleLine(&GetPosition(), &size, &point1, &point2) == true)
//			{
//				double dot = Math::dot_product((destination_position - point1), (point2 - point1)) / pow(line_length, 2);
//
//				double closest_x = point1.x + dot * line_dx;
//				double closest_y = point1.y + dot * line_dy;
//				Math::vec2 closest_point = { closest_x, closest_y };
//				doodle::push_settings();
//				doodle::set_outline_color(255, 0, 0, 255);
//				//doodle::draw_ellipse(closest_point.x - camera_position.x, closest_point.y + -camera_position.y, 20, 20);
//				//doodle::draw_line(point1_extended.x - camera_position.x, point1_extended.y + -camera_position.y, point2_extended.x - camera_position.x, point2_extended.y - camera_position.y);
//				doodle::pop_settings();
//
//				double dx = destination_position.x - closest_x;
//				double dy = destination_position.y - closest_y;
//
//				double distance_to_line = sqrt(pow(dx, 2) + pow(dy, 2));
//
//				if (distance_to_line <= size)
//				{
//					//too_close = true;
//					how_close = { dx / size, dy / size };
//				}
//			}
//		}
//	}
//
//	bool did_collide_wall = false;
//	bool did_passthrough_wall = false;
//	bool too_close_wall = false;
//	Math::vec2 how_close_wall{};
//
//	for (Wall* wall : walls)
//	{
//		if (wall->GetIsActive() == false)
//			continue;
//
//		Math::vec2 point1 = *wall->GetPoint1();
//		Math::vec2 point2 = *wall->GetPoint2();
//		CWall* cwall = dynamic_cast<CWall*>(wall);
//		if (cwall != nullptr)
//		{
//			point2 = cwall->GetCurrentPoint2();
//		}
//
//		double line_dx = point2.x - point1.x;
//		double line_dy = point2.y - point1.y;
//		double line_length = sqrt(pow(line_dx, 2) + pow(line_dy, 2));
//		Math::vec2 line_normal = { -line_dy / line_length, line_dx / line_length };
//		double line_angle = Math::angle_between(Math::ANGLE_ZERO, Math::vec2{ line_dx, line_dy });
//
//		// 1. is the player colliding with one of the walls?
//		if (did_collide_wall == false && Collision::CircleLine(&GetPosition(), &size, &point1, &point2) == true)
//		{
//			did_collide_wall = true;
//			position_delta = -line_normal * Math::dot_product(position_delta, line_normal);
//			doodle::push_settings();
//			doodle::set_outline_color(255, 255);
//			doodle::draw_line(point1.x - camera_position.x, point1.y + -camera_position.y, point2.x - camera_position.x, point2.y - camera_position.y);
//			doodle::pop_settings();
//		}
//
//		// 2. did the player move so fast that it moved straight through a wall, without colliding with it?
//		if (did_passthrough_wall == false && Collision::LineLine(&point1, &point2, &source_position, &destination_position) == true)
//		{
//			did_passthrough_wall = true;
//		}
//
//		// 3. is the player slightly overlapping with one of the walls?
//		if (too_close_wall == false && Collision::CircleLine(&GetPosition(), &size, &point1, &point2) == true)
//		{
//			double dot = Math::dot_product((destination_position - point1), (point2 - point1)) / pow(line_length, 2);
//
//			double closest_x = point1.x + dot * line_dx;
//			double closest_y = point1.y + dot * line_dy;
//			Math::vec2 closest_point = { closest_x, closest_y };
//
//			double dx = destination_position.x - closest_x;
//			double dy = destination_position.y - closest_y;
//
//			double distance_to_line = sqrt(pow(dx, 2) + pow(dy, 2));
//
//			if (distance_to_line <= size)
//			{
//				//too_close_wall = true;
//				how_close_wall = { dx / size, dy / size };
//			}
//		}
//
//	}
//
//	if (did_passthrough == true || did_passthrough_wall == true)
//	{
//		SetVelocity({ 0, 0 });
//		position_delta = Math::vec2{ 0, 0 };
//	}
//	else if (too_close == true || too_close_wall == true)
//	{
//		SetVelocity({ 0, 0 });
//		SetPosition(destination_position + how_close + how_close_wall);
//	}
//	else
//	{
//		SetPosition(source_position + position_delta);
//	}
//}


bool Bulbpuf::MapCollision(double dt)
{
	[[maybe_unused]] Math::vec2 destination_position = GetPosition() + GetVelocity() * dt;
	std::vector<ShapeMass*>* map = Engine::GetGameStateManager().GetGSComponent<CS230::MapManager>()->GetShapeMasses();
	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
	std::vector<Wall*> walls{};
	for (GameObject* object : *objects)
	{
		Wall* wall = dynamic_cast<Wall*>(object);
		if (wall != nullptr)
		{
			walls.push_back(wall);
		}
	}

	bool did_collide = false;
	bool did_passthrough = false;
	Math::vec2 how_close{};
	for (ShapeMass* mass : *map)
	{
		std::vector<Point*>* points = mass->GetPoints();
		for (int i = 0; i < points->size(); ++i)
		{
			Math::vec2 point1 = *(*points)[i]->GetPosition();
			Math::vec2 point2 = *(*points)[(i + 1) % points->size()]->GetPosition();
			double line_dx = point2.x - point1.x;
			double line_dy = point2.y - point1.y;
			double line_length = sqrt(pow(line_dx, 2) + pow(line_dy, 2));
			Math::vec2 line_normal = { -line_dy / line_length, line_dx / line_length };
			double line_angle = Math::angle_between(Math::ANGLE_ZERO, Math::vec2{ line_dx, line_dy });

			// 1. is the player colliding with one of the walls?
			if (did_collide == false && Collision::CircleLine(&GetPosition(), &size, &point1, &point2) == true)
			{
				return true;
			}

			// 2. did the player move so fast that it moved straight through a wall, without colliding with it?
			if (did_passthrough == false && Collision::LineLine(&point1, &point2, &GetPosition(), &destination_position) == true)
			{
				return true;
			}
		}
	}

	bool did_collide_wall = false;
	bool did_passthrough_wall = false;
	Math::vec2 how_close_wall{};

	for (Wall* wall : walls)
	{
		if (wall->GetIsActive() == false)
			continue;

		Math::vec2 point1 = *wall->GetPoint1();
		Math::vec2 point2 = *wall->GetPoint2();
		CWall* cwall = dynamic_cast<CWall*>(wall);
		if (cwall != nullptr)
		{
			point2 = cwall->GetCurrentPoint2();
		}

		double line_dx = point2.x - point1.x;
		double line_dy = point2.y - point1.y;
		double line_length = sqrt(pow(line_dx, 2) + pow(line_dy, 2));
		Math::vec2 line_normal = { -line_dy / line_length, line_dx / line_length };
		double line_angle = Math::angle_between(Math::ANGLE_ZERO, Math::vec2{ line_dx, line_dy });

		// 1. is the player colliding with one of the walls?
		if (did_collide_wall == false && Collision::CircleLine(&GetPosition(), &size, &point1, &point2) == true)
		{
			return true;
		}

		// 2. did the player move so fast that it moved straight through a wall, without colliding with it?
		if (did_passthrough_wall == false && Collision::LineLine(&point1, &point2, &GetPosition(), &destination_position) == true)
		{
			return true;
		}
	}
	return false;
}


//bool Bulbpuf::MapCollision()
//{
//	bool did_collide = false;
//	std::vector<ShapeMass*>* map = Engine::GetGameStateManager().GetGSComponent<CS230::MapManager>()->GetShapeMasses();
//	Math::vec2 camera_position = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>()->GetPosition();
//	for (ShapeMass* mass : *map)
//	{
//		std::vector<Point*>* points = mass->GetPoints();
//		for (int i = 0; i < points->size(); ++i)
//		{
//			Math::vec2 point1 = *(*points)[i]->GetPosition();
//			Math::vec2 point2 = *(*points)[(i + 1) % points->size()]->GetPosition();
//			did_collide = Collision::CircleLine(&GetPosition(), &size, &point1, &point2);
//			if (did_collide)
//			{
//				doodle::push_settings();
//				doodle::set_outline_color(80, 255, 0, 255);
//				doodle::draw_line(point1.x - camera_position.x, point1.y + -camera_position.y, point2.x - camera_position.x, point2.y - camera_position.y);
//				doodle::pop_settings();
//				return true;
//			}
//		}
//	}
//	return false;
//}

void Bulbpuf::UrchinCollision(double dt)
{
	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
	std::vector<Urchin*> urchins{};
	for (GameObject* object : *objects)
	{
		Urchin* urchin = dynamic_cast<Urchin*>(object);
		if (urchin != nullptr)
		{
			urchins.push_back(urchin);
		}
	}
	for (Urchin* urchin : urchins)
	{
		int const urchin_size = urchin->GetSize() / 2;
		if (Collision::CircleCircle(&GetPosition(), &(urchin->GetPosition()), &size, &urchin_size))
		{
			SetVelocity({ -(urchin->GetPosition().x - GetPosition().x - size) * 2, -(urchin->GetPosition().y - GetPosition().y - size) * 2 });
			urchined = true;
			urchinsound.play();
		}
	}
}


Math::vec2 Bulbpuf::GetCameraPosition()
{
	CS230::Camera* camera = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>();
	return camera->GetPosition();
}

void Bulbpuf::UpdatePosition(double dt)
{
	double dx = Engine::GetInput().GetMousePosition().x - (GetPosition().x - GetCameraPosition().x) - min_distance;
	double dy = Engine::GetInput().GetMousePosition().y - (GetPosition().y - GetCameraPosition().y) - min_distance;
	double distance = sqrt(pow(dx, 2) + pow(dy, 2));
	if (distance > stop_moving_distance) {
		SetVelocity({ dx * 2, dy * 2 });
	}
	if (distance < stop_moving_distance) {
		SetVelocity({ 0, 0 });
	}
}

double Bulbpuf::GetMouseDistance()
{
	CS230::Camera* camera = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>();
	double dx = Engine::GetInput().GetMousePosition().x - (GetPosition().x - camera->GetPosition().x) - min_distance;
	double dy = Engine::GetInput().GetMousePosition().y - (GetPosition().y - camera->GetPosition().y) - min_distance;
	double distance = sqrt(pow(dx, 2) + pow(dy, 2));
	return distance;
}

void Bulbpuf::State_Slow::Enter(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	if (light->GetCurrentLightColor() == LightColors::Red) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::SlowRed));
	}
	else if (light->GetCurrentLightColor() == LightColors::Green) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::SlowGreen));
	}
	else if (light->GetCurrentLightColor() == LightColors::Blue) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::SlowBlue));
	}
	else {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Slow));
	}

}
void Bulbpuf::State_Slow::Update(GameObject* object, double dt)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	bulbpuf->UpdatePosition(dt);
	if (bulbpuf->GetPosition().x < Engine::GetInput().GetMousePosition().x + bulbpuf->GetCameraPosition().x) {
		bulbpuf->SetScale({ 1, 1 });

	}
	else if (bulbpuf->GetPosition().x > Engine::GetInput().GetMousePosition().x + bulbpuf->GetCameraPosition().x) {
		bulbpuf->SetScale({ -1, 1 });
	}
}
void Bulbpuf::State_Slow::CheckExit(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	if (bulbpuf->GetVelocity() != Math::vec2({ 0,0 })) {
		bulbpuf->change_state(&bulbpuf->state_moving);
	}
	if (Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Right) == true)
	{
		bulbpuf->change_state(&bulbpuf->state_changing_color);
	}
}


void Bulbpuf::State_Moving::Enter(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	if (light->GetCurrentLightColor() == LightColors::Red) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::MovingRed));
	}
	else if (light->GetCurrentLightColor() == LightColors::Green) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::MovingGreen));
	}
	else if (light->GetCurrentLightColor() == LightColors::Blue) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::MovingBlue));
	}
	else {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Moving));
	}

}
void Bulbpuf::State_Moving::Update(GameObject* object, double dt)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	bulbpuf->UpdatePosition(dt);
	if (bulbpuf->GetPosition().x < Engine::GetInput().GetMousePosition().x + bulbpuf->GetCameraPosition().x) {
		bulbpuf->SetScale({ 1, 1 });

	}
	else if (bulbpuf->GetPosition().x > Engine::GetInput().GetMousePosition().x + bulbpuf->GetCameraPosition().x) {
		bulbpuf->SetScale({ -1, 1 });
	}
}
void Bulbpuf::State_Moving::CheckExit(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);

	if (bulbpuf->GetVelocity() == Math::vec2({ 0,0 })) {
		bulbpuf->change_state(&bulbpuf->state_slow);
	}
	if (Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Right) == true)
	{
		bulbpuf->change_state(&bulbpuf->state_changing_color);
	}
	if (bulbpuf->urchined == true)
	{
		bulbpuf->change_state(&bulbpuf->state_urchined);
	}
}



void Bulbpuf::State_Changing_Color::Enter(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	bulbpuf->speed_before_pause = { bulbpuf->GetVelocity().x, bulbpuf->GetVelocity().y };
	bulbpuf->SetVelocity({ 0, 0 });
	ColorWheel* colorwheel = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<ColorWheel>();
	// set colorwheel::is_active to true 
	colorwheel->SetIsActive(true);
	// pause animation
}
void Bulbpuf::State_Changing_Color::Update(GameObject* object, double dt)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
}
void Bulbpuf::State_Changing_Color::CheckExit(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	// check if right click is released
	if (Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Right) == false)
	{
		bulbpuf->SetVelocity(bulbpuf->speed_before_pause);
		if (bulbpuf->GetVelocity() != Math::vec2({ 0,0 })) {
			bulbpuf->change_state(&bulbpuf->state_moving);
		}
		if (bulbpuf->GetVelocity() == Math::vec2({ 0,0 })) {
			bulbpuf->change_state(&bulbpuf->state_slow);
		}
		ColorWheel* colorwheel = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<ColorWheel>();
		colorwheel->SetIsActive(false);
	}
}

void Bulbpuf::State_Urchined::Enter(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	if (light->GetCurrentLightColor() == LightColors::Red) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::UrchinedRed));
	}
	else if (light->GetCurrentLightColor() == LightColors::Green) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::UrchinedGreen));
	}
	else if (light->GetCurrentLightColor() == LightColors::Blue) {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::UrchinedBlue));
	}
	else {
		bulbpuf->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Urchined));;
	}
}
void Bulbpuf::State_Urchined::Update(GameObject* object, double dt)
{
	Math::vec2 camera_position = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>()->GetPosition();
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	bulbpuf->urchined_timer += dt;
	bulbpuf->SetVelocity({ bulbpuf->GetVelocity() * 0.9 });
}
void Bulbpuf::State_Urchined::CheckExit(GameObject* object)
{
	Bulbpuf* bulbpuf = static_cast<Bulbpuf*>(object);
	if (bulbpuf->urchined_timer >= bulbpuf->max_urchined_timer)
	{
		bulbpuf->urchined_timer = 0;
		bulbpuf->urchin_vector = { 0,0 };
		bulbpuf->urchined = false;
		bulbpuf->change_state(&bulbpuf->state_moving);
	}
}
