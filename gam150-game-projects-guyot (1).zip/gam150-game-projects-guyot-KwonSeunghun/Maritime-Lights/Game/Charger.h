/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Charger.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"
#include "LightColors.h"

class Charger : public CS230::GameObject
{
public:
	Charger(Math::vec2 position, enum LightColors color, unsigned char number);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;
	unsigned char GetNumber() { return number; }
	unsigned char GetCharge() { return charge; }

	//std::string GetType() override { return "Charger"; }

private:
	unsigned char number;
	unsigned char charge = 0;
	const unsigned char charge_speed = 128;
	enum LightColors color;

};