/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Tile.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 30, 2022
Updated:    May 30, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"
#include "LightColors.h"

class Tile : public CS230::GameObject
{
public:
	Tile(Math::vec2 position, LightColors color, LightColors correctcolor, bool fixed);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;
	bool IsCorrect() { return is_correct_color; }
	

private:
	enum LightColors color;
	enum LightColors correct_color;
	bool is_fixed;
	bool is_correct_color = false;
	enum class Animations {
		White,
		Red,
		Green,
		Blue
	};
};

