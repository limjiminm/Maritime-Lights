/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Urchin.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    June 3, 2023
Updated:    June 3, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"

class Urchin : public CS230::GameObject
{
public:
	Urchin(Math::vec2 startposition, Math::vec2 head, Math::vec2 tail, double speed);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;

	//std::string GetType() override { return "Urchin"; }
	double GetSize() const { return size; }

private:
	double speed = {};
	double where = {};
	double where_timer = {};
	Math::vec2 head;
	Math::vec2 tail;
	const double x_diff;
	const double y_diff = 0;
	Math::vec2 diff{};
	const double left = 0;
	const double right = 0;
	const double top = 0;
	const double bottom = 0;
	const double size = 80;

	enum class Animations {
		None
	};

};
