/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Nemo.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#include "Nemo.h"
#include "Bulbpuf.h"
#include "Light.h"
#include "Anemone.h"
#include "../Engine/Engine.h"
#include <doodle/drawing.hpp>

Nemo::Nemo(Math::vec2 position, enum LightColors color)
	: GameObject(position)
	, color(color)
{
	AddGOComponent(new CS230::Sprite("Assets/Nemo.spt", this));
}

void Nemo::Move(double dt)
{
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
	if (found_anemone)
	{
		double dx = my_anemone->GetPosition().x - GetPosition().x;
		double dy = my_anemone->GetPosition().y - GetPosition().y;
		double distance = sqrt(pow(dx, 2) + pow(dy, 2));
		if (distance > 2) {
			SetVelocity({ dx * 3, dy * 3 });
		}
		if (distance < 2) {
			SetVelocity({ 0, 0 });
			should_update = false;
		}
	}
	else if (color == light->GetCurrentLightColor())
	{
		double dx = light->GetPosition().x - GetPosition().x;
		double dy = light->GetPosition().y - GetPosition().y;
		double distance = sqrt(pow(dx, 2) + pow(dy, 2));

		if (distance < light->GetSize() / 2)
		{
			if (distance > brake_margin) {
				SetVelocity({ (dx - brake_margin) * 5, (dy - brake_margin) * 5 });
			}
			if (distance < brake_margin) {
				SetVelocity({ 0, 0 });
			}
		}
		else
		{ // outside of light perimeters; slow down
			if (GetVelocity().x > 0)
				UpdateVelocity({ -acceleration, 0 });
			else
				SetVelocity({ 0, GetVelocity().y });

			if (GetVelocity().y > 0)
				UpdateVelocity({ 0, -acceleration });
			else
				SetVelocity({ GetVelocity().x, 0 });
		}
	}
	else
	{ // inside wrong color; slow down
		if (GetVelocity().x > 0)
			UpdateVelocity({ -acceleration, 0 });
		else
			SetVelocity({ 0, GetVelocity().y });

		if (GetVelocity().y > 0)
			UpdateVelocity({ 0, -acceleration });
		else
			SetVelocity({ GetVelocity().x, 0 });
	}
	UpdatePosition(GetVelocity() * dt);
}

void Nemo::Update(double dt)
{
	if (!should_update)
		return;

	Bulbpuf* bulbpuf = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Bulbpuf>();
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();

	Move(dt);
	SearchAnemone();

	double light_dx = light->GetPosition().x - GetPosition().x;
	double light_dy = light->GetPosition().y - GetPosition().y;
	double light_distance = sqrt(pow(light_dx, 2) + pow(light_dy, 2));

	if (light_distance < light->GetSize() / 2)
	{
		rotation = Math::angle_between(Math::ANGLE_ZERO, bulbpuf->GetPosition() - GetPosition());
		if (GetPosition().y > bulbpuf->GetPosition().y)
		{
			rotation += Math::QUARTER_PI;
			rotation = Math::TWO_PI - rotation;
		}
		SetRotation(rotation);
	}
}

void Nemo::SearchAnemone()
{
	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
	std::vector<Anemone*> anemones{};
	for (GameObject* object : *objects)
	{
		Anemone* anemone = dynamic_cast<Anemone*>(object);
		if (anemone != nullptr)
		{
			anemones.push_back(anemone);
		}
	}
	std::vector<Wall*> walls{};
	for (GameObject* object : *objects)
	{
		Wall* wall = dynamic_cast<Wall*>(object);
		if (wall != nullptr)
		{
			walls.push_back(wall);
		}
	}

	for (Anemone* anemone : anemones)
	{
		if (anemone->GetColor() != color)
			continue; // wrong colored anemones do not have to be tested

		double dx = anemone->GetPosition().x - GetPosition().x;
		double dy = anemone->GetPosition().y - GetPosition().y;
		double distance = sqrt(pow(dx, 2) + pow(dy, 2));
		if ((distance < anemone_range) && !(anemone->HasNemo())) {
			anemone_number = anemone->GetNumber();
			//(*walls)[i]->set_is_active(false); // deactivate corresponding wall 
			// set velocity
			if (anemone->GetPosition().x > GetPosition().x)
				SetVelocity({ 100, GetVelocity().y });
			if (anemone->GetPosition().x < GetPosition().x)
				SetVelocity({ -100, GetVelocity().y });
			if (anemone->GetPosition().y > GetPosition().y)
				SetVelocity({ GetVelocity().x, 100 });
			if (anemone->GetPosition().y < GetPosition().y)
				SetVelocity({ GetVelocity().x, -100 });
			found_anemone = true;
			anemone->SetHasNemo(true);
			walls[anemone->GetNumber()]->SetIsActive(false);
			my_anemone = anemone;
			with_anemone.play();
		} // found anemone
	}
}

void Nemo::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::set_outline_color(255, 255);
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	GetGOComponent<CS230::Sprite>()->Draw(GetMatrix());
	switch (color)
	{
	case LightColors::Red:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Red));
		break;
	case LightColors::Green:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Green));
		break;
	case LightColors::Blue:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Blue));
		break;
	default:
		break;
	}
	//doodle::draw_ellipse(GetPosition().x, GetPosition().y, size, size); // temp hardcoded size values
	doodle::pop_settings();
}