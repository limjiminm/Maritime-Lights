/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  MovingWall.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee, Jimin Lim
Created:    May 30, 2022
Updated:    May 30, 2023
*/

#include "MovingWall.h"
#include <doodle/drawing.hpp>

MovingWall::MovingWall(Math::vec2 head_start, Math::vec2 head_begin, Math::vec2 head_end
					, Math::vec2 tail_start, Math::vec2 tail_begin, Math::vec2 tail_end
					, double speed)
	: GameObject({0, 0})
	, head(head_start), head_begin(head_begin), head_end(head_end)
	, tail(tail_start), tail_begin(tail_begin), tail_end(tail_end)
	, speed(speed)
{
	head_x_difference = -(head_begin.x - head_end.x);
	head_y_difference = -(head_begin.y - head_end.y);
	tail_x_difference = tail_begin.x - tail_end.x;
	tail_y_difference = tail_begin.y - tail_end.y;

	head_left = (head_begin.x > head_end.x) ? head_end.x : head_begin.x;
	head_right = (head_begin.x > head_end.x) ? head_begin.x : head_end.x;
	head_top = (head_begin.y > head_end.y) ? head_end.y : head_begin.y;
	head_bottom = (head_begin.y > head_end.y) ? head_begin.y : head_end.y;

	tail_left = (tail_begin.x > tail_end.x) ? tail_end.x : tail_begin.x;
	tail_right = (tail_begin.x > tail_end.x) ? tail_begin.x : tail_end.x;
	tail_top = (tail_begin.y > tail_end.y) ? tail_end.y : tail_begin.y;
	tail_bottom = (tail_begin.y > tail_end.y) ? tail_begin.y : tail_end.y;
}

void MovingWall::UpdateHead(double dt)
{
	head.x += dt * head_x_difference * speed;
	if (head.x > head_right || head.x < head_left)
	{
		speed *= -1;
	}
	head.y += dt * head_y_difference * speed;
	if (head.y > head_top || head.y < head_bottom)
	{
		speed *= -1;
	}
}

void MovingWall::UpdateTail(double dt)
{
	tail.x += dt * tail_x_difference * speed;
	if (tail.x > tail_right || tail.x < tail_left)
	{
		speed *= -1;
	}
	tail.y += dt * tail_y_difference * speed;
	if (tail.y > tail_top || tail.y < tail_bottom)
	{
		speed *= -1;
	}
}

void MovingWall::Update(double dt)
{
	this->UpdateHead(dt);
	this->UpdateTail(dt);
}

void MovingWall::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::set_outline_color(255, 255, 0, 255);
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	doodle::draw_line(head.x, head.y, tail.x, tail.y);
	doodle::set_outline_color(255, 120);
	doodle::draw_line(head_begin.x, head_begin.y, head_end.x, head_end.y);
	doodle::draw_line(tail_begin.x, tail_begin.y, tail_end.x, tail_end.y);
	doodle::pop_settings();
}

