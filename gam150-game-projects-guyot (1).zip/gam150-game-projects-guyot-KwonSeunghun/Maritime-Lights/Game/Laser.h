/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Laser.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 3, 2023
Updated:    May 4, 2023
*/
#pragma once
#include "..\Maritime-Lights\Engine\GameObject.h"

class Laser : public CS230::GameObject {
public:
    Laser(Math::vec2 start_position);
    ~Laser();
    void Update(double dt) override;
private:

    class State_On : public State {
    public:
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "On"; }
    };
    class State_Off : public State {
        virtual void Enter(GameObject* object) override;
        virtual void Update(GameObject* object, double dt) override;
        virtual void CheckExit(GameObject* object) override;
        std::string GetName() override { return "Off"; }
    };
    State_On state_on;
    State_Off state_off;

};