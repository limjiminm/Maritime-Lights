/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  ClearCircle.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#pragma once
#include "../Engine/GameObjectManager.h"
#include "../Engine/Vec2.h"
#include "Bulbpuf.h"

class ClearCircle : public CS230::GameObject
{
public:
	ClearCircle(Math::vec2 position, int stages, bool map_clear);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;
	Math::vec2 return_position() { return position; }
	int return_stage() { return stages; }
	bool return_clear() { return map_clear; }
	bool AreAllTilesCorrect();
private:
	Math::vec2 position;
	int stages;
	bool map_clear;
	double radius = 100;
	bool clear_fixed;
};