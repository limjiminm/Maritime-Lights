/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Tile.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 30, 2022
Updated:    May 30, 2023
*/

#include "Tile.h"
#include "Light.h"
#include "../Engine/Engine.h"
#include <doodle/drawing.hpp>
#include "../Engine/GameObject.h"

Tile::Tile(Math::vec2 position, LightColors color, LightColors correctcolor, bool fixed) 
	: GameObject(position)
 	, color(color)
	, correct_color(correctcolor)
	, is_fixed(fixed)
{
	if (fixed == true)
		is_correct_color = true;
	AddGOComponent(new CS230::Sprite("Assets/Tile.spt", this));
	color = LightColors::White;
}

void Tile::Update(double dt)
{
	if (is_fixed == true)
	{
		return; // fixed tiles should not change color
	}
	// check for collision with light, check its color, and change self color to match light color
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	double dx = GetPosition().x - light->GetPosition().x;
	double dy = GetPosition().y - light->GetPosition().y;
	double distance = sqrt(pow(dx, 2) + pow(dy, 2));
	if (distance < light->GetSize() / 2)
	{
		// change self color to match light color
		color = light->GetCurrentLightColor();
	}

	if (color == correct_color)
		is_correct_color = true;
	else
		is_correct_color = false;
}

void Tile::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::no_outline();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	GetGOComponent<CS230::Sprite>()->Draw(GetMatrix());
	switch (color)
	{
	case LightColors::Red:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Red));
		break;
	case LightColors::Green:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Green));
		break;
	case LightColors::Blue:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Blue));
		break;
	case LightColors::White:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::White));
	}
	//doodle::draw_rectangle(GetPosition().x, GetPosition().y, 30, 30); // temp hardcoded size values

	doodle::pop_settings();
}
