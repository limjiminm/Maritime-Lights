/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Menu.h
Project:    CS230 Engine
Author:     Jonathan Holmes , Jimin Lim(jimin.lim@digipen.edu)
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#pragma once
#include "../Engine/GameState.h"
#include "../Engine/Texture.h"

class Menu : public CS230::GameState {
public:
    Menu();
    void Load() override;
    void Update(double dt) override;
    void Unload() override;
    void Draw() override;

    std::string GetName() override { return "Menu"; }

private:
    
    CS230::Texture* backgrounds;
    CS230::Texture* Title;
    CS230::Texture* Start_off;
    CS230::Texture* Tutorial_off;
    CS230::Texture* Credits_off;
    CS230::Texture* Exit_off;

    CS230::Texture* Start_on;
    CS230::Texture* Tutorial_on;
    CS230::Texture* Credits_on;
    CS230::Texture* Exit_on;

};

