/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Anemone.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee, Bada Kim
Created:    May 30, 2022
Updated:    May 30, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"
#include "LightColors.h"

class Anemone : public CS230::GameObject
{
    friend class Light;
public:
    Anemone(Math::vec2 position, enum LightColors color, unsigned char number);
    void Draw(Math::TransformationMatrix camera_matrix) override;
    LightColors GetColor() { return color; }
    unsigned char GetNumber() { return number; }
    bool HasNemo() { return has_nemo; }
    void SetHasNemo(bool value) { has_nemo = value; }

    //std::string GetType() override { return "Anemone"; }

private:
    enum class Animations {
        None,
        Red,
        Green,
        Blue,
        NemoNone,
        NemoRed,
        NemoGreen,
        NemoBlue
    };
    LightColors color;
    unsigned char number;
    bool has_nemo;
};
