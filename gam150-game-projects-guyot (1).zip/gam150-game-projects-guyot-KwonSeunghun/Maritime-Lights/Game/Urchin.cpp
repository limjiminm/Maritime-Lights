/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Urchin.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    June 3, 2023
Updated:    June 3, 2023
*/

#include "Urchin.h"
#include <doodle/drawing.hpp>

Urchin::Urchin(Math::vec2 startposition, Math::vec2 head, Math::vec2 tail, double speed)
	: GameObject(startposition)
	, head(head)
	, tail(tail) 
	, speed(speed)
	, where(0)
	, x_diff(tail.x - head.x)
	, y_diff(tail.y - head.y)
	, diff({x_diff, y_diff})
	, left((head.x <= tail.x) ? head.x : tail.x)
	, right((head.x >= tail.x) ? head.x : tail.x)
	, top((head.y >= tail.y) ? head.y : tail.y)
	, bottom((head.y <= tail.y) ? head.y : tail.y)
{
	SetVelocity({ x_diff * speed, y_diff * speed }); // distance Urchin will move per second
	AddGOComponent(new CS230::Sprite("Assets/Urchin.spt", this));
}

void Urchin::Update(double dt)
{
	// flip x velocity
	if (x_diff != 0)
	{
		if (GetPosition().x > right || GetPosition().x < left)
		{
			SetVelocity(GetVelocity() * -1);
		}
	}
	else
	{
		// flip y velocity
		if (GetPosition().y > top || GetPosition().y < bottom)
		{
			SetVelocity({ GetVelocity().x, GetVelocity().y * -1 });
		}
	}

	//SetVelocity(diff * where);
	//where += speed * dt;
	//if ((where < 0 || where > speed) && where_timer >= 0.2)
	//{
	//	where *= -1;
	//	where_timer = 0;
	//}
	//where_timer += dt;
	UpdatePosition(GetVelocity() * dt);
}

void Urchin::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	GetGOComponent<CS230::Sprite>()->Draw(GetMatrix());
	//Sprite* sprite = GetGOComponent<Sprite>();
	this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::None));
	doodle::pop_settings();



}
