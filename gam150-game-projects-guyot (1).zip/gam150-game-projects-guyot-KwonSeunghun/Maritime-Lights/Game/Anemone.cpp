/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Anemone.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee, Bada Kim
Created:    May 30, 2022
Updated:    May 30, 2023
*/

#include "Anemone.h"
#include <doodle/drawing.hpp>

Anemone::Anemone(Math::vec2 position, enum LightColors color, unsigned char number)
	: GameObject(position)
	, color(color)
	, number(number)
{
	AddGOComponent(new CS230::Sprite("Assets/Anemone.spt", this));
}

void Anemone::Draw(Math::TransformationMatrix camera_matrix)
{
	//Anemone* anemone = static_cast<Anemone*>;

	doodle::push_settings();
	doodle::set_outline_color(255, 255);
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	GetGOComponent<CS230::Sprite>()->Draw(GetMatrix());
	if (has_nemo == false) {
		switch (color)
		{
		case LightColors::Red:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Red));
			break;
		case LightColors::Green:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Green));
			break;
		case LightColors::Blue:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Blue));
			break;
		default:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::None));
		}
	}
	else if (has_nemo == true) {
		switch (color)
		{
		case LightColors::Red:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::NemoRed));
			break;
		case LightColors::Green:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::NemoGreen));
			break;
		case LightColors::Blue:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::NemoBlue));
			break;
		default:
			this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::NemoNone));
		}
	}

	doodle::pop_settings();
}