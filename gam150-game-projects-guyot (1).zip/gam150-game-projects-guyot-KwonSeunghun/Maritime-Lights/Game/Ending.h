#pragma once
#include "../Engine/GameState.h"
#include "../Engine/Texture.h"
#include "../Engine/GameObjectManager.h"

class Ending : public CS230::GameState {
public:
    Ending();
    void Load() override;
    void Update(double dt) override;
    void Unload() override;
    void Draw() override;

    std::string GetName() override { return "Ending"; }

private:

    CS230::Texture* ending;
    double timer = 0.0;

};