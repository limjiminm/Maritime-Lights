/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Turorial1.cpp
Project:    CS230 Engine
Author:     Jimin Lim, Bada Kim
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#include "../Engine/Engine.h"
#include "States.h"
#include "Tutorial1.h"
#include "../Engine/Input.h"
#include "doodle/drawing.hpp"

Tutorial1::Tutorial1() {}

void Tutorial1::Load()
{};

void Tutorial1::Unload()
{}

void Tutorial1::Update(double dt)
{
    if (Engine::GetInput().GetMousePosition().x > 150 && Engine::GetInput().GetMousePosition().x < 150 + 148 && Engine::GetInput().GetMousePosition().y > 80 && Engine::GetInput().GetMousePosition().y < 162 && Engine::GetInput().MouseJustPressed(CS230::Input::MouseButtons::Left) == true)
    {
        //prev_butt
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Tutorial));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }

    if (Engine::GetInput().GetMousePosition().x > 1000 && Engine::GetInput().GetMousePosition().x < 1000 + 137 && Engine::GetInput().GetMousePosition().y > 70 && Engine::GetInput().GetMousePosition().y < 147 && Engine::GetInput().MouseJustPressed(CS230::Input::MouseButtons::Left) == true)
    {
        //Next_butt
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Tutorial2));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }

}

void Tutorial1::Draw()
{

    Tutorial_image1 = Engine::GetTextureManager().Load("Assets/Tutorial_image1.png");
    Tutorial_image1->Draw(Math::TranslationMatrix{ Math::vec2{0,0} });

    Prev_off = Engine::GetTextureManager().Load("Assets/Prev_off.png"); //148 x 82
    Prev_off->Draw(Math::TranslationMatrix{ Math::vec2{150,80} });

    if (Engine::GetInput().GetMousePosition().x > 150 && Engine::GetInput().GetMousePosition().x < 150 + 148 && Engine::GetInput().GetMousePosition().y > 80 && Engine::GetInput().GetMousePosition().y < 162)
    {
        Prev_on = Engine::GetTextureManager().Load("Assets/Prev_on.png"); //148 x 82
        Prev_on->Draw(Math::TranslationMatrix{ Math::vec2{150,80} });
    }

    Next_off = Engine::GetTextureManager().Load("Assets/Next_off.png"); //158 x 80
    Next_off->Draw(Math::TranslationMatrix{ Math::vec2{1000,70} });

    if (Engine::GetInput().GetMousePosition().x > 1000 && Engine::GetInput().GetMousePosition().x < 1000 + 137 && Engine::GetInput().GetMousePosition().y > 70 && Engine::GetInput().GetMousePosition().y < 147)
    {
        Next_on = Engine::GetTextureManager().Load("Assets/Next_on.png"); //158 x 80
        Next_on->Draw(Math::TranslationMatrix{ Math::vec2{1000,70} });
    }
}

