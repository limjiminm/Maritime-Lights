/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Charger.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#include "Charger.h"
#include "Light.h"
#include <doodle/drawing.hpp>
#include "../Engine/Engine.h"

Charger::Charger(Math::vec2 position, enum LightColors color, unsigned char number)
	: GameObject(position)
	, color(color)
	, number(number)
{

}

void Charger::Update(double dt)
{
	// check for collision with light
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	double dx = GetPosition().x - light->GetPosition().x;
	double dy = GetPosition().y - light->GetPosition().y;
	double distance = sqrt(pow(dx, 2) + pow(dy, 2));
	unsigned char charge_diff = dt * charge_speed;
	if (distance < light->GetSize() / 2 && color == light->GetCurrentLightColor())
	{
		// check if matching color
		// if matching color, increment charge
		if (charge + charge_diff >= 255) // overflow guard
			charge = 255;
		else
			charge += dt * charge_speed;
	}
	else
	{
		// decrement charge
		if (charge_diff >= charge) // overflow guard
			charge = 0;
		else
			charge -= charge_diff;
	}
}

void Charger::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	doodle::set_outline_color(255, 255);
	// change fill color according to charge
	// draw ellipse
	switch (color)
	{
	case LightColors::Red:
		doodle::set_fill_color(255, 0, 0, 255);
		break;
	case LightColors::Green:
		doodle::set_fill_color(0, 255, 0, 255);
		break;
	case LightColors::Blue:
		doodle::set_fill_color(0, 0, 255, 255);
		break;
	default:
		doodle::set_fill_color(255, 255);
	}
	doodle::draw_ellipse(GetPosition().x, GetPosition().y, 30, 30);
	doodle::set_fill_color(255, 255 - charge); // white mask 
	doodle::draw_ellipse(GetPosition().x, GetPosition().y, 30, 30);
	doodle::pop_settings();
}