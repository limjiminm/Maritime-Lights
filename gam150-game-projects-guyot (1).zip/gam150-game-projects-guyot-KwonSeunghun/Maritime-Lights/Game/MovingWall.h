/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  MovingWall.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee, Jimin Lim
Created:    May 30, 2022
Updated:    May 30, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"

class MovingWall : public CS230::GameObject
{
public:
	MovingWall(Math::vec2 head_start, Math::vec2 head_begin, Math::vec2 head_end
			, Math::vec2 tail_start, Math::vec2 tail_begin, Math::vec2 tail_end
			, double speed);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;

private:
	double speed;

	Math::vec2 head = {};
	Math::vec2 head_begin;
	Math::vec2 head_end;
	double head_left;
	double head_right;
	double head_top;
	double head_bottom;
	void UpdateHead(double dt);

	Math::vec2 tail = {};
	Math::vec2 tail_begin;
	Math::vec2 tail_end;
	double tail_left;
	double tail_right;
	double tail_top;
	double tail_bottom;
	void UpdateTail(double dt);

	double head_x_difference;
	double head_y_difference;
	double tail_x_difference;
	double tail_y_difference;
};