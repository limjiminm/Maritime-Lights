/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Turorial1.h
Project:    CS230 Engine
Author:     Jimin Lim, Bada Kim
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#pragma once
#include "../Engine/GameState.h"
#include "../Engine/Texture.h"
#include "../Engine/soundeffect.h"

class Tutorial1 : public CS230::GameState {
public:
    Tutorial1();
    void Load() override;
    void Update(double dt) override;
    void Unload() override;
    void Draw() override;

    std::string GetName() override { return "Tutorial1"; }

private:

    CS230::Texture* Tutorial_image1;
    CS230::Texture* Exit_off;
    CS230::Texture* Exit_on;

    CS230::Texture* Prev_off;
    CS230::Texture* Prev_on;

    CS230::Texture* Next_off;
    CS230::Texture* Next_on;
    
    SoundEffect button = SoundEffect("Assets/button.wav");
};

