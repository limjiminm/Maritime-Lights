/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  UrchinNemo2.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Jimin Lim
Created:    May 1, 2022
Updated:    May 2, 2023
*/

#include "../Engine/Engine.h"
#include "../Engine/GameObjectManager.h"
#include "../Engine/MapManager.h"
#include "../Engine/ShowCollision.h"
#include "States.h"
#include "UrchinNemo2.h"
#include "Bulbpuf.h"
#include "Light.h"
#include "ColorWheel.h"
#include "MovingWall.h"
#include "Tile.h"
#include "Charger.h"
#include "Nemo.h"
#include "Anemone.h"
#include "ClearCircle.h"

UrchinNemo2::UrchinNemo2() :
    bulbpuf_ptr(nullptr) {}


void UrchinNemo2::Load()
{
    AddGSComponent(new CS230::GameObjectManager());
    Math::vec2 start_position = GetGSComponent<CS230::GameObjectManager>()->LoadObjects("Assets/UrchinNemo2.objects");
    bulbpuf_ptr = new Bulbpuf(start_position);
    GetGSComponent<CS230::GameObjectManager>()->Add(bulbpuf_ptr);

#ifdef _DEBUG
    AddGSComponent(new CS230::ShowCollision());
#endif

    Math::ivec2 windowsize = Engine::GetWindow().GetSize();
    AddGSComponent(new CS230::Camera({ { 0.5 * Engine::GetWindow().GetSize().x, 0.5 * Engine::GetWindow().GetSize().y },
        { 0.55 * Engine::GetWindow().GetSize().x, 0.55 * Engine::GetWindow().GetSize().y } }));
    AddGSComponent(new CS230::GameObjectManager);
    AddGSComponent(new CS230::MapManager);

    GetGSComponent<CS230::MapManager>()->Load("Assets/UrchinNemo2.mapdata");

    GetGSComponent<CS230::Camera>()->SetPosition(start_position);
    GetGSComponent<CS230::Camera>()->SetLimit({ { 0, 0 }, { Engine::GetWindow().GetSize() } }); // temp hardcoded limit 
}

void UrchinNemo2::Update(double dt)
{
    GetGSComponent<CS230::GameObjectManager>()->UpdateAll(dt);
    if (Engine::GetInput().KeyJustReleased(CS230::Input::Keys::Enter)) {
        Engine::GetGameStateManager().ClearNextGameState();
    }
    if (Engine::GetInput().KeyJustReleased(CS230::Input::Keys::R)) {
        Engine::GetGameStateManager().ReloadGameState();
    }
    GetGSComponent<CS230::Camera>()->Update(bulbpuf_ptr->GetPosition());
}

void UrchinNemo2::Draw()
{
    Engine::GetWindow().Clear(0x030C54FF);
    Math::TransformationMatrix camera_matrix = GetGSComponent<CS230::Camera>()->GetMatrix();
    GetGSComponent<CS230::MapManager>()->Draw(camera_matrix);
    GetGSComponent<CS230::GameObjectManager>()->DrawAll(camera_matrix);
}

void UrchinNemo2::Unload()
{
    GetGSComponent<CS230::MapManager>()->Unload();
}