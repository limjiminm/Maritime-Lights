/*
copyright (c) 2023 digipen institute of technology
reproduction or distribution of this file or its contents without
prior written consent is prohibited
file name:  colorwheel.cpp
project:    gam150 guyot - maritime lights
author:     hankyung lee
created:    may 6, 2022
updated:    may 6, 2023
*/

#pragma once
#include "ColorWheel.h"
#include "Bulbpuf.h"
#include "Light.h"
#include <doodle/drawing.hpp> // also replace with sprite
#include "../engine/engine.h" // for input
#include "../engine/vec2.h" // for angles
#include "../Engine/Camera.h"

ColorWheel::ColorWheel(Math::vec2 start_position)
	: GameObject(start_position),
	is_active(false)
{

}

void ColorWheel::Update(double dt)
{
	if (is_active == false)
	{
		return;
	}
	Bulbpuf* bulbpuf = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Bulbpuf>();
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	CS230::Camera* camera = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>();
	if (light == nullptr)
	{
		throw std::runtime_error("colorwheel::update: light was nullptr");
	}
	SetPosition(bulbpuf->GetPosition());
	double dx = Engine::GetInput().GetMousePosition().x - (GetPosition().x - camera->GetPosition().x);
	double dy = Engine::GetInput().GetMousePosition().y - (GetPosition().y - camera->GetPosition().y);
	Math::vec2 vec_pos_mouse = { dx, dy };
	double angle = Math::angle_between(Math::ANGLE_ZERO, vec_pos_mouse);
	if (GetPosition().y - camera->GetPosition().y < Engine::GetInput().GetMousePosition().y)
		angle = Math::TWO_PI - angle;

	if (angle > Math::PI / 6 && angle < Math::PI / 6 * 5) {
		light->SetLightColor(LightColors::White, false);
		light->SetLightColor(LightColors::Red, false);
		light->SetLightColor(LightColors::Green, true);
		light->SetLightColor(LightColors::Blue, false);
	}
	if (angle > Math::PI / 6 * 5 && angle < Math::PI * 4 / 3) {
		light->SetLightColor(LightColors::White, false);
		light->SetLightColor(LightColors::Red, false);
		light->SetLightColor(LightColors::Green, false);
		light->SetLightColor(LightColors::Blue, true);
	}
	if (angle > Math::PI * 4 / 3 || angle < Math::PI / 6) {
		light->SetLightColor(LightColors::White, false);
		light->SetLightColor(LightColors::Red, true);
		light->SetLightColor(LightColors::Green, false);
		light->SetLightColor(LightColors::Blue, false);
	}
	double distance = sqrt(pow(dx, 2) + pow(dy, 2));
	if (distance >= size) {
		light->SetLightColor(LightColors::White, true);
		light->SetLightColor(LightColors::Red, false);
		light->SetLightColor(LightColors::Green, false);
		light->SetLightColor(LightColors::Blue, false);
	}
}

void ColorWheel::Draw(Math::TransformationMatrix camera_matrix)
{
	if (is_active == false)
	{
		return;
	}
	doodle::push_settings();
	doodle::no_outline();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	//red
	doodle::set_fill_color({ 255, 80, 80, 160 });
	doodle::draw_quad(GetPosition().x, GetPosition().y,
		GetPosition().x, GetPosition().y + size,
		GetPosition().x + size * cos(Math::PI / 6), GetPosition().y + size * sin(Math::PI / 6),
		GetPosition().x + size * cos(Math::PI / 6), GetPosition().y - size * sin(Math::PI / 6));
	//green
	doodle::set_fill_color({ 80, 255, 80, 160 });
	doodle::draw_quad(GetPosition().x, GetPosition().y,
		GetPosition().x + size * cos(Math::PI / 6), GetPosition().y - size * sin(Math::PI / 6),
		GetPosition().x, GetPosition().y - size,
		GetPosition().x - size * cos(Math::PI / 6), GetPosition().y - size * sin(Math::PI / 6));
	//blue
	doodle::set_fill_color({ 80, 80, 255, 160 });
	doodle::draw_quad(GetPosition().x, GetPosition().y,
		GetPosition().x, GetPosition().y + size,
		GetPosition().x - size * cos(Math::PI / 6), GetPosition().y + size * sin(Math::PI / 6),
		GetPosition().x - size * cos(Math::PI / 6), GetPosition().y - size * sin(Math::PI / 6));
	doodle::pop_settings();
}
