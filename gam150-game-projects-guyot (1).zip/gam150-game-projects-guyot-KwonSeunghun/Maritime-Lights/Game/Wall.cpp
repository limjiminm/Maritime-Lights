	/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Wall.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    June 1, 2023
Updated:    June 1, 2023
*/

#include "Wall.h"
#include "Charger.h"
#include "../Engine/Engine.h"
#include <doodle/drawing.hpp>

Wall::Wall(Math::vec2 position1, Math::vec2 position2, unsigned char the_number, LightColors color)
	: GameObject({ 0,0 })
	, point1(position1)
	, point2(position2)
	, number(the_number)
	, color(color)
	, is_active(true)
{
	length = sqrt(pow(position2.x - position1.x, 2) + pow(position2.y - position1.y, 2));
	vector = point2 - point1;
}

void Wall::Update(double dt)
{

}

void Wall::SetIsActive(bool value)
{
	if (value == false)
	{
		doodle_opacity = 80;
	}
	is_active = value;
}

void Wall::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	switch (color)
	{
	case LightColors::Red:
		doodle::set_outline_color(255, 0, 0, doodle_opacity);
		break;
	case LightColors::Green:
		doodle::set_outline_color(0, 255, 0, doodle_opacity);
		break;
	case LightColors::Blue:
		doodle::set_outline_color(0, 0, 255, doodle_opacity);
		break;
	default:
		doodle::set_outline_color(255, doodle_opacity);
	}
	doodle::set_outline_width(5);
	doodle::draw_line(point1.x, point1.y, point2.x, point2.y);

	doodle::pop_settings();
}

CWall::CWall(Math::vec2 position1, Math::vec2 position2, unsigned char the_number, LightColors color)
	: Wall(position1, position2, the_number, color)
	, current_point2(position2)
{

}

void CWall::Update(double dt)
{
	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
	std::vector<Charger*> chargers{};
	for (GameObject* object : *objects)
	{
		Charger* charger = dynamic_cast<Charger*>(object);
		if (charger != nullptr)
		{
			chargers.push_back(charger);
		}
	}
	unsigned char my_charge = chargers[number]->GetCharge();
	double current_point2_x = point1.x + (point2.x - point1.x) * (255 - my_charge) / 255;
	double current_point2_y = point1.y + (point2.y - point1.y) * (255 - my_charge) / 255;
	current_point2 = { current_point2_x, current_point2_y };
}

void CWall::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	switch (color)
	{
	case LightColors::Red:
		doodle::set_outline_color(255, 0, 0, doodle_opacity);
		break;
	case LightColors::Green:
		doodle::set_outline_color(0, 255, 0, doodle_opacity);
		break;
	case LightColors::Blue:
		doodle::set_outline_color(0, 0, 255, doodle_opacity);
		break;
	default:
		doodle::set_outline_color(255, doodle_opacity);
	}
	doodle::set_outline_width(5);
	doodle::draw_line(point1.x, point1.y, current_point2.x, current_point2.y);

	doodle::pop_settings();
}