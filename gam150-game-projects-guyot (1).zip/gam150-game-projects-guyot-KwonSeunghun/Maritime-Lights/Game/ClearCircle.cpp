/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  ClearCircle.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#include "ClearCircle.h"
#include "../Engine/Engine.h"
#include <doodle/drawing.hpp>
#include "Bulbpuf.h"
#include "Tile.h"

ClearCircle::ClearCircle(Math::vec2 position, int stages, bool map_clear)
	: GameObject(position), stages(stages), map_clear(map_clear) 
{
	AddGOComponent(new CS230::Sprite("Assets/Portal.spt", this));
}

void ClearCircle::Update(double dt)
{
	//Math::vec2 player_position = bulbpuf_ptr->GetPosition();
	Bulbpuf* bulbpuf = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Bulbpuf>();
	Tile* tile = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Tile>();
	auto sprite = bulbpuf->GetGOComponent<CS230::Sprite>();
	if (clear_fixed) {
		if (GetPosition().x + radius/ 2 >= bulbpuf->GetPosition().x &&         // right of the left edge AND
			GetPosition().x + radius / 2 <= bulbpuf->GetPosition().x + sprite->GetFrameSize().x / 2 &&   // left of the right edge AND
			GetPosition().y + radius / 2 >= bulbpuf->GetPosition().y &&         // below the top AND
			GetPosition().y + radius / 2 <= bulbpuf->GetPosition().y + sprite->GetFrameSize().y / 2) {    // above the bottom

			Engine::GetGameStateManager().SetNextGameState(stages);
		}
	}
}

void ClearCircle::Draw(Math::TransformationMatrix camera_matrix)
{
		doodle::push_settings();
		doodle::apply_matrix(
			camera_matrix[0][0],
			camera_matrix[1][0],
			camera_matrix[0][1],
			camera_matrix[1][1],
			camera_matrix[0][2],
			camera_matrix[1][2]);
		//doodle::draw_rectangle(GetPosition().x, GetPosition().y, 30, 30); // temp hardcoded size values
		doodle::set_outline_width(5);
		doodle::set_outline_color(0, 255, 255, 255);
		doodle::set_fill_color(0, 255, 255, 255);
		if ((AreAllTilesCorrect() || map_clear)) {
				clear_fixed = true;
		}
		if (clear_fixed) {
			GetGOComponent<CS230::Sprite>()->Draw(GetMatrix());
		}

		else {
			doodle::no_fill();
			doodle::draw_ellipse(GetPosition().x, GetPosition().y, radius, radius);
		}



		doodle::pop_settings();
}

bool ClearCircle::AreAllTilesCorrect() {
	std::vector<GameObject*>* objects = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetObjects();
	std::vector<Tile*> tiles = {};

	for (GameObject* object : *objects)
	{
		Tile* tile = dynamic_cast<Tile*>(object);
		if (tile != nullptr)
		{
			tiles.push_back(tile);
		}
	}
	for (Tile* tile : tiles)
	{
		if (!(tile->IsCorrect())) {
			return false;
		}
	}
	return true;
}