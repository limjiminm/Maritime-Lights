/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Wall.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    June 1, 2023
Updated:    June 1, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"
#include "LightColors.h"

class Wall : public CS230::GameObject
{
public:
	Wall(Math::vec2 position1, Math::vec2 position2, unsigned char the_number, LightColors color);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;

	Math::vec2* const GetPoint1() { return &point1; }
	Math::vec2* const GetPoint2() { return &point2; }
	unsigned char const GetNumber() { return number; }
	LightColors const GetColor() { return color; }
	bool GetIsActive() { return is_active; }
	void SetIsActive(bool value);

	//std::string GetType() override { return "Wall"; }

protected:
	Math::vec2 point1;
	Math::vec2 point2;
	double length{};
	Math::vec2 vector{};
	unsigned char number;
	LightColors color;
	bool is_active = true;
	unsigned char doodle_opacity = 255;

};

class CWall : public Wall
{
public:
	CWall(Math::vec2 position1, Math::vec2 position2, unsigned char the_number, LightColors color);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;
	Math::vec2 GetCurrentPoint2() { return current_point2; }
private:
	Math::vec2 current_point2{};
};