/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Light.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 4, 2022
Updated:    May 4, 2023
*/

#pragma once
#include "Light.h"
#include "../Engine/Engine.h"
#include <doodle/drawing.hpp> // replace with sprite
#include "Bulbpuf.h"

Light::Light(Math::vec2 start_position)
	: GameObject(start_position)
{
	lightcolors.resize(static_cast<int>(LightColors::Unknown));
	lightcolors[static_cast<int>(LightColors::White)] = false;
	lightcolors[static_cast<int>(LightColors::Red)] = false;
	lightcolors[static_cast<int>(LightColors::Green)] = false;
	lightcolors[static_cast<int>(LightColors::Blue)] = false;
	AddGOComponent(new CS230::Sprite("Assets/Light.spt", this));
}

Light::~Light()
{
}

void Light::Update(double dt)
{
	Bulbpuf* bulbpuf = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Bulbpuf>();
	SetPosition(bulbpuf->GetPosition());
	//if (doodlecolor_outdated)
		//UpdateDoodleColor(); // change to sprite instead of doodlecolor
}

void Light::Draw(Math::TransformationMatrix camera_matrix)
{
	doodle::push_settings();
	doodle::set_outline_color(255, 0, 0, 255);
	doodle::set_fill_color(doodlecolor_red, doodlecolor_green, doodlecolor_blue, 80);
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	doodle::draw_ellipse(GetPosition().x, GetPosition().y, size, size);
	doodle::pop_settings();
	//printf("%d %d %d %d\n", lightcolors[0] == true, lightcolors[1] == true, lightcolors[2] == true, lightcolors[3] == true);
}

void Light::SetLightColor(LightColors color, bool value)
{
	lightcolors[static_cast<int>(color)] = value;
	UpdateDoodleColor();
}

LightColors Light::GetCurrentLightColor()
{
	int i = 0;
	for (; i < lightcolors.size(); ++i)
	{
		if (lightcolors[i] == true)
		{
			break;
		}
	}
	return static_cast<LightColors>(i);
}

void Light::UpdateDoodleColor()
{	
	if (lightcolors[static_cast<int>(LightColors::White)])
	{
		doodlecolor_red = 255;
		doodlecolor_green = 255;
		doodlecolor_blue = 255;
		return;
	}
	doodlecolor_red = lightcolors[static_cast<int>(LightColors::Red)] * 255;
	doodlecolor_green = lightcolors[static_cast<int>(LightColors::Green)] * 255;
	doodlecolor_blue = lightcolors[static_cast<int>(LightColors::Blue)] * 255;
}
