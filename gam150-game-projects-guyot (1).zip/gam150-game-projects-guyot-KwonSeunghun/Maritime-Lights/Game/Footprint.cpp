/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Footprint.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    June 3, 2023
Updated:    June 3, 2023
*/

#include "Footprint.h"
#include "Light.h"
#include <doodle/drawing.hpp>
#include "../Engine/Engine.h"

Footprint::Footprint(Math::vec2 position, LightColors color)
	: GameObject(position)
	, color(color)
{
	AddGOComponent(new CS230::Sprite("Assets/Footprint.spt", this));
}

void Footprint::Update(double dt)
{
	// check for collision with light
	Light* light = Engine::GetGameStateManager().GetGSComponent<CS230::GameObjectManager>()->GetGameObject<Light>();
	double dx = GetPosition().x - light->GetPosition().x;
	double dy = GetPosition().y - light->GetPosition().y;
	double distance = sqrt(pow(dx, 2) + pow(dy, 2));
	if (distance < light->GetSize() / 2 && color == light->GetCurrentLightColor())
	{ // make visible
		is_visible = true;
	}
	else
	{ // make invisible
		is_visible = false;
	}
}

void Footprint::Draw(Math::TransformationMatrix camera_matrix)
{
	if (!is_visible)
		return;

	doodle::push_settings();
	doodle::apply_matrix(
		camera_matrix[0][0],
		camera_matrix[1][0],
		camera_matrix[0][1],
		camera_matrix[1][1],
		camera_matrix[0][2],
		camera_matrix[1][2]);
	GetGOComponent<CS230::Sprite>()->Draw(GetMatrix());
	// draw ellipse
	switch (color)
	{
	case LightColors::Red:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Red));
		break;
	case LightColors::Green:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Green));
		break;
	case LightColors::Blue:
		this->GetGOComponent<CS230::Sprite>()->PlayAnimation(static_cast<int>(Animations::Blue));
		break;
	default:
		break;
	}
	doodle::pop_settings();
}
