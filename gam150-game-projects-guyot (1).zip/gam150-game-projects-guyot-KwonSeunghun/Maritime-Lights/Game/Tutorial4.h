/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Turorial4.h
Project:    CS230 Engine
Author:     Jimin Lim, Bada Kim
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#pragma once
#include "../Engine/GameState.h"
#include "../Engine/Texture.h"
#include "../Engine/soundeffect.h"

class Tutorial4 : public CS230::GameState {
public:
    Tutorial4();
    void Load() override;
    void Update(double dt) override;
    void Unload() override;
    void Draw() override;

    std::string GetName() override { return "Tutorial4"; }

private:

    CS230::Texture* Tutorial_image4;

    CS230::Texture* Exit_off;
    CS230::Texture* Exit_on;

    CS230::Texture* Prev_off;
    CS230::Texture* Prev_on;

    CS230::Texture* Next_off;
    CS230::Texture* Next_on;

    SoundEffect button = SoundEffect("Assets/button.wav");
};
