/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  States.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 1, 2022
Updated:    May 2, 2023
*/

#pragma once

enum class States {
    Splash,
    Menu,
    Tutorial,
    Tutorial1,
    Tutorial2,
    Tutorial3,
    Tutorial4,
    Credits,
    Nemo1,
    Nemo2,
    Tile1,
    Tile2,
    Maze,
    UrchinNemo1,
    UrchinNemo2,
    Mix1,
    Mix2,
    Ending
};
