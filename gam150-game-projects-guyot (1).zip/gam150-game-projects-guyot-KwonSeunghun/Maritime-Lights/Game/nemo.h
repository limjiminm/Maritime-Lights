/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Nemo.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 23, 2022
Updated:    May 23, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"
#include "LightColors.h"
#include "Anemone.h"
#include "../Engine/soundeffect.h"

class Nemo : public CS230::GameObject
{
public:
	Nemo(Math::vec2 position, enum LightColors color);
	void Move(double dt);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;
	void SearchAnemone();

private:
    enum class Animations {
        Nemo,
        Red,
        Green,
        Blue
    };

    static constexpr int max_speed = 450;
    static constexpr int min_brake_speed = 10;
    static constexpr int acceleration = 12;
    static constexpr int brake_margin = 80;
    static constexpr int anemone_range = 200;

    static constexpr int size = 20;

    LightColors color;

    Anemone* my_anemone;
    bool found_anemone = false;
    unsigned char anemone_number = 0;
    bool should_update = true;

    static constexpr double rotation_speed = 5;
    double rotation = 0;

    SoundEffect with_anemone = SoundEffect("Assets/nemoanemone.wav");
};