/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Laser.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Seunghun Kwon
Created:    May 3, 2023
Updated:    May 4, 2023
*/

#include "Laser.h"
#include "Clam.h"
//#include "doodle/doodle.hpp"
//using namespace doodle;

Laser::Laser(Math::vec2 start_position) : GameObject(start_position)
{

}

Laser::~Laser()
{	

}

void Laser::Update(double dt)
{

}

void Laser::State_On::Enter(GameObject* object)
{

}
void Laser::State_On::Update(GameObject* object, double dt)
{
//	if (������ ���� != Bulbpubp::with_clam)
//		clam->change_state(&laser->off);
//}
}

void Laser::State_On::CheckExit(GameObject* object)
{
	Clam* clam = static_cast<Clam*>(object);
	Laser* laser = static_cast<Laser*>(object);
}

void Laser::State_Off::Enter(GameObject* object)
{
	
}
void Laser::State_Off::Update(GameObject* object, double dt)
{
	Laser* laser = static_cast<Laser*>(object);
	//��� ����
}

void Laser::State_Off::CheckExit(GameObject* object)
{
	Laser* laser = static_cast<Laser*>(object);
//	if (������ ���� == Bulbpubp::with_clam)
//		clam->change_state(&laser->state_on);
//}
}