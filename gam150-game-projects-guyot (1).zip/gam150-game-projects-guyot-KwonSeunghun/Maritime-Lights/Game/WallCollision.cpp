///*
//Copyright (C) 2023 DigiPen Institute of Technology
//Reproduction or distribution of this file or its contents without
//prior written consent is prohibited
//File Name:  WallCollision.cpp
//Project:    GAM150 Guyot - Maritime Lights
//Author:     Hankyung Lee
//Created:    May 7, 2022
//Updated:    May 7, 2023
//*/
//
//#include "WallCollision.h"
//#include <iterator>					// for std::next
//#include "../Engine/Camera.h"
//#include "../Engine/Collision.h"
//#include "../Engine/Engine.h"
//#include "../Engine/Sprite.h"
//#include "../Engine/MapManager.h"
//#include "../Engine/ShapeMass.h"
//#include "../Engine/Point.h"
//#include <doodle/drawing.hpp>		// for testing 
//
//WallCollision::WallCollision(CS230::GameObject& object) : object(object) 
//{
//	objectsize = (object.GetGOComponent<CS230::Sprite>()->GetFrameSize().x >= object.GetGOComponent<CS230::Sprite>()->GetFrameSize().y)
//		? object.GetGOComponent<CS230::Sprite>()->GetFrameSize().x / 2 : object.GetGOComponent<CS230::Sprite>()->GetFrameSize().y / 2;
//}
//
//void WallCollision::Update(double) {
//	Math::TransformationMatrix display_matrix = Engine::GetGameStateManager().GetGSComponent<CS230::Camera>()->GetMatrix();
//	Math::vec2 current_position = object.GetPosition();
//	Math::vec2 previous_position = object.GetPreviousPosition();
//	//doodle::push_settings();
//	//doodle::set_outline_color(255, 0, 0, 255);
//	//doodle::apply_matrix(display_matrix[0][0], display_matrix[1][0], display_matrix[0][1], display_matrix[1][1], display_matrix[0][2], display_matrix[1][2]);
//	//doodle::draw_ellipse(current_position.x, current_position.y, objectsize * 2, objectsize * 2);
//	//doodle::pop_settings();
//	std::vector<ShapeMass*>* shape_masses = Engine::GetGameStateManager().GetCurrentGamestate()->GetGSComponent<CS230::MapManager>()->GetShapeMasses();
//	for (ShapeMass* shape : *shape_masses)
//	{
//		std::vector<Point*>* points = shape->GetPoints();
//		for (int i = 0; i < points->size(); ++i)
//		{
//			Point* p1 = points->operator[](i);
//			Point* p2 = points->operator[]((i + 1) % points->size());
//			if (Collision::CircleLine(&current_position, &objectsize, p1->GetPosition(), p2->GetPosition()))
//			//if (DistanceBetween::LinePoint(&current_position, p1->GetPosition(), p2->GetPosition()) <= objectsize)
//			//	|| Collision::LineLine(p1->GetPosition(), p2->GetPosition(), &current_position, &previous_position))
//			{
//				doodle::push_settings();
//				doodle::set_outline_color(255, 0, 255, 255);
//				doodle::apply_matrix(display_matrix[0][0], display_matrix[1][0], display_matrix[0][1], display_matrix[1][1], display_matrix[0][2], display_matrix[1][2]);
//				doodle::draw_line(p1->GetPosition()->x, p1->GetPosition()->y,
//					p2->GetPosition()->x, p2->GetPosition()->y);
//				doodle::pop_settings();
//				colliding = true;
//				return;
//			}
//		}
//		//for (Point* point : *points)
//		//{
//		//	doodle::push_settings();
//		//	doodle::set_outline_color(255, 255, 255, 255);
//		//	doodle::apply_matrix(display_matrix[0][0], display_matrix[1][0], display_matrix[0][1], display_matrix[1][1], display_matrix[0][2], display_matrix[1][2]);
//		//	doodle::draw_line(point->GetPosition()->x, point->GetPosition()->y,
//		//		std::next(point, 1)->GetPosition()->x, std::next(point, 1)->GetPosition()->y);
//		//	doodle::pop_settings();
//		//	if (DistanceBetween::LinePoint(&current_position, point->GetPosition(), std::next(point, 1)->GetPosition()) <= objectsize
//		//		|| Collision::LineLine(point->GetPosition(), std::next(point, 1)->GetPosition(), &current_position, &previous_position))
//		//	{
//		//		colliding = true;
//		//		return;
//		//	}
//		//}
//		// last point with first point
//		//if (DistanceBetween::LinePoint(&current_position, (*points->begin())->GetPosition(), (*points->end())->GetPosition()) <= objectsize
//		//	|| Collision::LineLine((*points->begin())->GetPosition(), (*points->end())->GetPosition(), &current_position, &previous_position))
//		//{
//		//	colliding = true;
//		//	return;
//		//}
//	}
//	// if none of the above: 
//	colliding = false;
//}
//
