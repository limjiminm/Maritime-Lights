/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Turorial4.cpp
Project:    CS230 Engine
Author:     Jimin Lim, Bada Kim
Created:    May 03, 2023
Updated:    May 03, 2023
*/

#include "../Engine/Engine.h"
#include "States.h"
#include "Tutorial4.h"
#include "../Engine/Input.h"
#include "doodle/drawing.hpp"
#include "Background.h"

Tutorial4::Tutorial4() {}

void Tutorial4::Load()
{};

void Tutorial4::Unload()
{}

void Tutorial4::Update(double dt)
{
    if (Engine::GetInput().GetMousePosition().x > 150 && Engine::GetInput().GetMousePosition().x < 150 + 148 && Engine::GetInput().GetMousePosition().y > 70 && Engine::GetInput().GetMousePosition().y < 152 && Engine::GetInput().MouseJustPressed(CS230::Input::MouseButtons::Left) == true)
    {
        //prev_butt
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Tutorial3));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }

    if (Engine::GetInput().GetMousePosition().x > 1000 && Engine::GetInput().GetMousePosition().x < 1000 + 137 && Engine::GetInput().GetMousePosition().y > 70 && Engine::GetInput().GetMousePosition().y < 147 && Engine::GetInput().MouseJustPressed(CS230::Input::MouseButtons::Left) == true)
    {
        //Exit_butt
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Menu));
        Engine::GetInput().MouseDown(CS230::Input::MouseButtons::Left) == false;
        button.play();
    }

}

void Tutorial4::Draw()
{

    Tutorial_image4 = Engine::GetTextureManager().Load("Assets/Tutorial_image4.png");
    Tutorial_image4->Draw(Math::TranslationMatrix{ Math::vec2{0,0} });

    Prev_off = Engine::GetTextureManager().Load("Assets/Prev_off.png"); //148 x 82
    Prev_off->Draw(Math::TranslationMatrix{ Math::vec2{150,70} });

    if (Engine::GetInput().GetMousePosition().x > 150 && Engine::GetInput().GetMousePosition().x < 150 + 148 && Engine::GetInput().GetMousePosition().y > 70 && Engine::GetInput().GetMousePosition().y < 152)
    {
        Prev_on = Engine::GetTextureManager().Load("Assets/Prev_on.png"); //148 x 82
        Prev_on->Draw(Math::TranslationMatrix{ Math::vec2{150,70} });
    }

    Exit_off = Engine::GetTextureManager().Load("Assets/Exit_off.png"); //137 x 77
    Exit_off->Draw(Math::TranslationMatrix{ Math::vec2{1000,70} });

    if (Engine::GetInput().GetMousePosition().x > 1000 && Engine::GetInput().GetMousePosition().x < 1000 + 137 && Engine::GetInput().GetMousePosition().y > 70 && Engine::GetInput().GetMousePosition().y < 147)
    {
        Exit_on = Engine::GetTextureManager().Load("Assets/Exit_on.png");
        Exit_on->Draw(Math::TranslationMatrix{ Math::vec2{1000,70} });
    }
}
