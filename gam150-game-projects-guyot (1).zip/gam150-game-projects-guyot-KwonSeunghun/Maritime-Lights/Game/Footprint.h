/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Footprint.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    June 3, 2023
Updated:    June 3, 2023
*/

#pragma once
#include "../Engine/GameObject.h"
#include "../Engine/Vec2.h"
#include "LightColors.h"

class Footprint : public CS230::GameObject
{
public:
	Footprint(Math::vec2 position, LightColors color);
	void Update(double dt) override;
	void Draw(Math::TransformationMatrix camera_matrix) override;

private:
	LightColors color;
	bool is_visible;
	double size = 15;

	enum class Animations {
		Red,
		Green,
		Blue
	};
};
