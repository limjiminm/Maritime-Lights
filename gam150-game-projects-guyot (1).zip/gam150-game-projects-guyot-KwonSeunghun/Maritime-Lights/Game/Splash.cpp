/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Splash.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 1, 2022
Updated:    May 2, 2023
*/

#include "../Engine/Engine.h"
#include "../Engine/Matrix.h"
#include "States.h"
#include "Splash.h"

Splash::Splash() {

}

void Splash::Load() {
    counter = 0.0;

    texture = Engine::GetTextureManager().Load("Assets/DigiPen.png");

}

void Splash::Update(double dt) {
    Engine::GetLogger().LogDebug(std::to_string(counter));
    counter += dt;
    if (counter >= 3) {
        texture = Engine::GetTextureManager().Load("Assets/Logo.png");
    }
    if (counter >= 5) {
        Engine::GetGameStateManager().SetNextGameState(static_cast<int>(States::Menu));
    }

}

void Splash::Unload() {

}

void Splash::Draw() {
    Engine::GetWindow().Clear(UINT_MAX);
    texture->Draw(Math::TranslationMatrix({ (Engine::GetWindow().GetSize() - texture->GetSize()) / 2.0 }));
}
