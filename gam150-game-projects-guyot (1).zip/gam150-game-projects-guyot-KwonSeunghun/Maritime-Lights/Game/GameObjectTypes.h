/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Collision.h
Project:    CS230 Engine
Author:     Jonathan Holmes, Hankyung Lee
Created:    March 8, 2023
Updated:    May 15, 2023
*/

#pragma once
#include "Anemone.h"
#include "Bulbpuf.h"
#include "Charger.h"
#include "ColorWheel.h"
#include "Footprint.h"
#include "Light.h"
#include "MovingWall.h"
#include "Nemo.h"
#include "Tile.h"
#include "Urchin.h"
#include "Wall.h"

enum class GameObjectTypes {
    Anemone,
    Bulbpuf,
    Charger,
    ColorWheel,
    Footprint,
    Light,
    MovingWall,
    Nemo,
    Tile,
    Urchin,
    Wall,

    Count
};
