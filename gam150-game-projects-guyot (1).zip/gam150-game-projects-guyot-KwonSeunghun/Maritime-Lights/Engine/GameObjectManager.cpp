/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  GameObjectManager.h
Project:    Maritime Lights
Author:     Hankyung Lee
Created:    April 21, 2023
Updated:    May 31, 2023
*/

#include "GameObjectManager.h"
#include "Engine.h"
#include "../Game/States.h"
#include "../Game/ClearCircle.h"

void CS230::GameObjectManager::Add(GameObject* object)
{
    objects.push_back(object);
    //objects_by_type[object->GetType()].push_back(object);
}

Math::vec2 CS230::GameObjectManager::LoadObjects(const std::filesystem::path& file_path)
{
    objects.clear();
    Math::vec2 start_position = {};
    Math::vec2 temp_position = {};
    char temp_color_text = {};
    LightColors temp_color = {};
    unsigned char anemone_number = 0;
    unsigned char charger_number = 0;
    unsigned char wall_number = 0;
    unsigned char cwall_number = 0;

    if (file_path.extension() != ".objects") {
        throw std::runtime_error(file_path.generic_string() + " is not a .objects file");
    }
    std::ifstream in_file(file_path);

    if (in_file.is_open() == false) {
        throw std::runtime_error("Failed to load " + file_path.generic_string());
    }

    std::string text;
    in_file >> text;
    while (in_file.eof() == false) {
        temp_position = {};
        temp_color_text = {};
        temp_color = {};
        if (text == "StartPosition")
        {
            in_file >> start_position.x;
            in_file >> start_position.y;
        }
        else if (text == "Anemone")
        {
            in_file >> temp_position.x;
            in_file >> temp_position.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            Add(new Anemone(temp_position, temp_color, anemone_number));
            ++anemone_number;
        }
        else if (text == "Charger")
        {
            in_file >> temp_position.x;
            in_file >> temp_position.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            Add(new Charger(temp_position, temp_color, charger_number));
            ++charger_number;
        }
        else if (text == "Footprint")
        {
            in_file >> temp_position.x;
            in_file >> temp_position.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            Add(new Footprint(temp_position, temp_color));
        }
        else if (text == "MovingWall")
        {
            Math::vec2 head_start;
            Math::vec2 head_begin;
            Math::vec2 head_end;
            Math::vec2 tail_start;
            Math::vec2 tail_begin;
            Math::vec2 tail_end;
            double speed;
            in_file >> head_start.x; in_file >> head_start.y;
            in_file >> head_begin.x; in_file >> head_begin.y;
            in_file >> head_end.x; in_file >> head_end.y;
            in_file >> tail_start.x; in_file >> tail_start.y;
            in_file >> tail_begin.x; in_file >> tail_begin.y;
            in_file >> tail_end.x; in_file >> tail_end.y;
            in_file >> speed;
            Add(new MovingWall(head_start, head_begin, head_end, tail_start, tail_begin, tail_end, speed));
        }
        else if (text == "Nemo")
        {
            in_file >> temp_position.x;
            in_file >> temp_position.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            Add(new Nemo(temp_position, temp_color));
        }
        else if (text == "Tile")
        {
            LightColors correct_color = {};
            char truefalse = {};
            bool bool_truefalse = {};
            in_file >> temp_position.x;
            in_file >> temp_position.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                correct_color = LightColors::Red;
                break;
            case 'G':
                correct_color = LightColors::Green;
                break;
            case 'B':
                correct_color = LightColors::Blue;
                break;
            default:
                correct_color = LightColors::White;
            }
            in_file >> truefalse;
            bool_truefalse = truefalse == 'T' ? true : truefalse == 'F' ? false : 0;
            Add(new Tile(temp_position, temp_color, correct_color, bool_truefalse));
        }
        else if (text == "Urchin")
        {
            Math::vec2 startposition{};
            Math::vec2 head{};
            Math::vec2 tail{};
            double speed{};
            in_file >> startposition.x >> startposition.y
                >> head.x >> head.y
                >> tail.x >> tail.y
                >> speed;
            Add(new Urchin(startposition, head, tail, speed));
        }
        else if (text == "Wall")
        {
            Math::vec2 temp_point1 = {};
            Math::vec2 temp_point2 = {};
            in_file >> temp_point1.x;
            in_file >> temp_point1.y;
            in_file >> temp_point2.x;
            in_file >> temp_point2.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            Add(new Wall(temp_point1, temp_point2, wall_number, temp_color));
            ++wall_number;
        }
        else if (text == "CWall")
        {
            Math::vec2 temp_point1 = {};
            Math::vec2 temp_point2 = {};
            in_file >> temp_point1.x;
            in_file >> temp_point1.y;
            in_file >> temp_point2.x;
            in_file >> temp_point2.y;
            in_file >> temp_color_text;
            switch (temp_color_text)
            {
            case 'R':
                temp_color = LightColors::Red;
                break;
            case 'G':
                temp_color = LightColors::Green;
                break;
            case 'B':
                temp_color = LightColors::Blue;
                break;
            default:
                temp_color = LightColors::White;
            }
            Add(new CWall(temp_point1, temp_point2, cwall_number, temp_color));
            ++cwall_number;
        }
        else if (text == "ClearCircle") {
        std::string temp_stage = {};
        char truefalse = {};
        bool bool_truefalse = {};
        int stage = {};
        in_file >> temp_position.x;
        in_file >> temp_position.y;
        in_file >> temp_stage;

        if (temp_stage == "Nemo1") {
            stage = static_cast<int>(States::Nemo1);
        }
        else if (temp_stage == "Nemo2") {
            stage = static_cast<int>(States::Nemo2);
        }
        else if (temp_stage == "Tile1") {
            stage = static_cast<int>(States::Tile1);
        }
        else if (temp_stage == "Tile2") {
            stage = static_cast<int>(States::Tile2);
        }
        else if (temp_stage == "Maze") {
            stage = static_cast<int>(States::Maze);
        }
        else if (temp_stage == "UrchinNemo1") {
            stage = static_cast<int>(States::UrchinNemo1);
        }
        else if (temp_stage == "UrchinNemo2") {
            stage = static_cast<int>(States::UrchinNemo2);
        }
        else if (temp_stage == "Mix1") {
            stage = static_cast<int>(States::Mix1);
        }
        else if (temp_stage == "Mix2") {
            stage = static_cast<int>(States::Mix2);
        }
        else if (temp_stage == "Ending") {
            stage = static_cast<int>(States::Ending);
        }

        else
        {
            Engine::GetLogger().LogError("Unknown command: " + text);
        }
        in_file >> truefalse;
        bool_truefalse = truefalse == 'T' ? true : truefalse == 'F' ? false : 0;
        Add(new ClearCircle(temp_position, stage, bool_truefalse));
        }
        else
        {
        Engine::GetLogger().LogError("Unknown command: " + text);
        }
        in_file >> text;
    }
    //Add(new Bulbpuf(start_position));
    Add(new Light(start_position));
    Add(new ColorWheel(start_position));
    return start_position;  // Bulbpuf needs to be manually added in each Mode file, because of bulbpuf_ptr.
    // This return value is used as the start_position of Bulbpuf (within each Mode files)
}

void CS230::GameObjectManager::UpdateAll(double dt)
{
    for (int i = 0; i < objects.size(); ++i)
    {
        objects[i]->Update(dt);
    }
}

void CS230::GameObjectManager::DrawAll(Math::TransformationMatrix camera_matrix)
{
    for (int i = 0; i < objects.size(); ++i)
    {
        objects[i]->Draw(camera_matrix);
    }
}

void CS230::GameObjectManager::Unload()
{
    for (int i = 0; i < objects.size(); ++i)
    {
        objects[i]->~GameObject();
    }
    objects.clear();
}

