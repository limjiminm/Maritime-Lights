/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Collision.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 3, 2022
Updated:    May 3, 2023
*/

#include "Collision.h"
#include <math.h> // for sqrt and pow

bool Collision::CircleCircle(const Math::vec2* c1, const Math::vec2* c2, const int* r1, const int* r2)
{
	double dx = c1->x - c2->x;
	double dy = c1->y - c2->y;
	double dist = sqrt(pow(dx, 2) + pow(dy, 2));
	return (dist <= (*r1 + *r2));
}

bool Collision::CircleLine(const Math::vec2* c, const int* r, const Math::vec2* l1, const Math::vec2* l2)
{
	double ldx = l2->x - l1->x;
	double ldy = l2->y - l1->y;
	double length = sqrt(pow(ldx, 2) + pow(ldy, 2));

	double dot = Math::dot_product((*c - *l1), (*l2 - *l1)) / pow(length, 2);

	double closest_x = l1->x + dot * ldx;
	double closest_y = l1->y + dot * ldy;
	Math::vec2 closest_point = { closest_x, closest_y };

	double cdx = c->x - closest_x;
	double cdy = c->y - closest_y;
	double distance = sqrt(pow(cdx, 2) + pow(cdy, 2));

	if (distance <= *r && LinePoint(&closest_point, l1, l2))
	{
		return true;
	}
	else if (CirclePoint(c, r, l1) || CirclePoint(c, r, l2))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Collision::CirclePoint(const Math::vec2* c, const int* r, const Math::vec2* p)
{
	double dx = c->x - p->x;
	double dy = c->y - p->y;
	double dist = sqrt(pow(dx, 2) + pow(dy, 2));
	return (dist <= *r);
}

bool Collision::LineLine(const Math::vec2* p1, const Math::vec2* p2, const Math::vec2* p3, const Math::vec2* p4)
{ // http://www.jeffreythompson.org/collision-detection/line-line.php
	double uA = ((p4->x - p3->x) * (p1->y - p3->y) - (p4->y - p3->y) * (p1->x - p3->x))
		/ ((p4->y - p3->y) * (p2->x - p1->x) - (p4->x - p3->x) * (p2->y - p1->y));
	double uB = ((p2->x - p1->x) * (p1->y - p3->y) - (p2->y - p1->y) * (p1->x - p3->x))
		/ ((p4->y - p3->y) * (p2->x - p1->x) - (p4->x - p3->x) * (p2->y - p1->y));
	if (uA >= 0 && uA <= 1 && uB >= 0 && uB <= 1)
	{
		return true;
	}
	return false;
}

bool Collision::LinePoint(const Math::vec2* p, const Math::vec2* l1, const Math::vec2* l2)
{
	double dx1 = p->x - l1->x;
	double dy1 = p->y - l1->y;
	double dist1 = sqrt(pow(dx1, 2) + pow(dy1, 2));

	double dx2 = p->x - l2->x;
	double dy2 = p->y - l2->y;
	double dist2 = sqrt(pow(dx2, 2) + pow(dy2, 2));

	double ldx = l1->x - l2->x;
	double ldy = l1->y - l2->y;
	double length = sqrt(pow(ldx, 2) + pow(ldy, 2));

	return (static_cast<int>(dist1 + dist2) == static_cast<int>(length));
}

// DistanceBetween
double DistanceBetween::PointPoint(const Math::vec2* p1, const Math::vec2* p2)
{
	double dx = p1->x - p2->x;
	double dy = p1->y - p2->y;
	return sqrt(pow(dx, 2) + pow(dy, 2));
}

double DistanceBetween::LinePoint(const Math::vec2* p, const Math::vec2* l1, const Math::vec2* l2)
{
	double length = PointPoint(l1, l2);
	return (abs((l2->x - l1->x) * (l1->y - p->y) - (l1->x - p->x) * (l2->y - l1->y)) / length);
}