/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  ShapeMass.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 2, 2022
Updated:    May 2, 2023
*/

#include "ShapeMass.h"

ShapeMass::ShapeMass(char shape_no) : shape_no(shape_no)
{
	points_in_shape.clear();
}

void ShapeMass::AddPoint(Point* point)
{
	points_in_shape.push_back(point);
	// ++points_count;
}
