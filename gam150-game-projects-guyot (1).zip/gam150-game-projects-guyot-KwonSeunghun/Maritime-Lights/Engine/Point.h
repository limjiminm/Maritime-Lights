/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Point.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 2, 2022
Updated:    May 2, 2023
*/

#pragma once
#include "../Engine/Vec2.h"

struct Point
{
	Point(Math::vec2 position, char shape_no, char point_no) : position(position), shape_no(shape_no), point_no(point_no) {}
	friend class ShapeMass;
	Math::vec2* GetPosition() { return &position; }
	char* GetShapeNo() { return &shape_no; }
	char* GetPointNo() { return &point_no; }

private:
	Math::vec2 position;
	char shape_no;
	char point_no;
};

