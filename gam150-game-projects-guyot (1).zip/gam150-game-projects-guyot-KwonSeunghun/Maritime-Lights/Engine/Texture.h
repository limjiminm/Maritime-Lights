/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Texture.h
Project:    CS230 Engine
Author:     Jonathan Holmes, Hankyung Lee
Created:    March 8, 2023
Updated:    April 7, 2023
*/
#pragma once
#include <doodle/image.hpp>
#include "Matrix.h"
#include "Vec2.h"

namespace CS230 {
    class Texture {
    friend class TextureManager;
    friend class Font;
    public:
        Texture() {}
        void Draw(Math::TransformationMatrix display_matrix);
        void Draw(Math::TransformationMatrix display_matrix, Math::ivec2 texel_position, Math::ivec2 frame_size);
        Math::ivec2 GetSize();
    private:
        Texture(doodle::Image&& doodle_image);
        Texture(const std::filesystem::path& file_path);
        unsigned int GetPixel(Math::ivec2 texel);
        doodle::Image image;
    };
}
