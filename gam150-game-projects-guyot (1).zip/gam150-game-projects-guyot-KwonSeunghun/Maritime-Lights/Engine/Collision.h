/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  Collision.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 3, 2022
Updated:    May 3, 2023
*/

#pragma once
#include "../Engine/Vec2.h"

namespace Collision
{ // add in alphabetical order!!
	bool CircleCircle(const Math::vec2*, const Math::vec2*, const int*, const int*);
	bool CircleLine(const Math::vec2*, const int* r, const Math::vec2*, const Math::vec2*);
	bool CirclePoint(const Math::vec2*, const int*, const Math::vec2*);
	bool LineLine(const Math::vec2*, const Math::vec2*, const Math::vec2*, const Math::vec2*);
	bool LinePoint(const Math::vec2*, const Math::vec2*, const Math::vec2*);
}

namespace DistanceBetween
{
	double PointPoint(const Math::vec2*, const Math::vec2*);
	double LinePoint(const Math::vec2*, const Math::vec2*, const Math::vec2*);
}