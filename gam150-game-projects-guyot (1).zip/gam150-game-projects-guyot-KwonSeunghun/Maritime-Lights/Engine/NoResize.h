#pragma once

void make_window_not_resizable();
