/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  MapManager.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 3, 2022
Updated:    May 3, 2023
*/

#pragma once
#include <filesystem>
#include <vector>
#include "Component.h"
#include "ShapeMass.h"
#include "Point.h"

namespace Math { class TransformationMatrix; }

namespace CS230 {
    class MapManager : public Component {
    public:
        void Load(const std::filesystem::path& file_path);
        void Unload();
        void Draw(Math::TransformationMatrix camera_matrix);

        std::vector<ShapeMass*>* GetShapeMasses() { return &shape_masses; }

    private:
        std::vector<ShapeMass*> shape_masses;
    };
}
