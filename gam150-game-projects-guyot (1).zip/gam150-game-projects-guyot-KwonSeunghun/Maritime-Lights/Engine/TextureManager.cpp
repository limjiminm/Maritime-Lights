/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  TextureManager.h
Project:    CS230 Engine
Author:     Hankyung Lee
Created:    April 27, 2023
*/

#include "Texture.h"
#include "TextureManager.h"

CS230::Texture* CS230::TextureManager::Load(const std::filesystem::path& file_path)
{
	return textures[file_path] = new Texture(file_path);
}

void CS230::TextureManager::Unload()
{
	textures.clear();
}