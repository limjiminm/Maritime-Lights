/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  ShapeMass.h
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 2, 2022
Updated:    May 2, 2023
*/

#pragma once
#include <vector>
#include "Point.h"

class ShapeMass {
public:
	ShapeMass(char shape_no);
	void AddPoint(Point *point);
	void Draw();
	
	std::vector<Point*>* GetPoints() { return &points_in_shape; }

private:
	// char points_count;
	const char shape_no;
	std::vector<Point*> points_in_shape{};

};
