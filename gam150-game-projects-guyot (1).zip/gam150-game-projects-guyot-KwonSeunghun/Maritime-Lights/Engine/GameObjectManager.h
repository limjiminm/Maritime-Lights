/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  GameObjectManager.h
Project:    Maritime Lights
Author:     Jonathan Holmes, Hankyung Lee
Created:    March 8, 2023
Updated:    May 31, 2023
*/

#pragma once
#include <filesystem>
#include <vector>
#include <map>
#include "GameObject.h"
#include "Matrix.h"
#include "Component.h"
#include "../Game/GameObjectTypes.h"

namespace Math { class TransformationMatrix; }

namespace CS230 {
    class GameObjectManager : public Component {
    public:
        void Add(GameObject* object);
        Math::vec2 LoadObjects(const std::filesystem::path& file_path);
        void Unload();
        std::vector<GameObject*>* GetObjects() { return &objects; }
        std::map<std::string, std::vector<GameObject*>>* GetObjectsByType() { return &objects_by_type; }
        template<typename T>
        T* GetGameObject()
        {
            for (GameObject* object : objects) {
                T* ptr = dynamic_cast<T*>(object);
                if (ptr != nullptr) {
                    return ptr;
                }
            }
            return nullptr;
        }

        void UpdateAll(double dt);
        void DrawAll(Math::TransformationMatrix camera_matrix);
    private:
        std::vector<GameObject*> objects;
        std::map<std::string, std::vector<GameObject*>> objects_by_type;

    };
}