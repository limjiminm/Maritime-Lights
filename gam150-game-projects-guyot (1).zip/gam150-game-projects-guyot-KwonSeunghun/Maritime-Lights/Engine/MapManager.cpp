/*
Copyright (C) 2023 DigiPen Institute of Technology
Reproduction or distribution of this file or its contents without
prior written consent is prohibited
File Name:  MapManager.cpp
Project:    GAM150 Guyot - Maritime Lights
Author:     Hankyung Lee
Created:    May 3, 2022
Updated:    May 3, 2023
*/

#include "MapManager.h"
#include <fstream>
#include <doodle/drawing.hpp>
#include "../Engine/Engine.h"
#include "../Engine/Matrix.h"

void CS230::MapManager::Load(const std::filesystem::path& file_path)
{
	shape_masses.clear();
    char current_shape_reading = -1; // so that it starts out at 0
    char point_no = 0;

    if (file_path.extension() != ".mapdata") {
        throw std::runtime_error(file_path.generic_string() + " is not a .mapdata file");
    }
    std::ifstream in_file(file_path);

    if (in_file.is_open() == false) {
        throw std::runtime_error("Failed to load " + file_path.generic_string());
    }

    std::string text;
    in_file >> text;
    while (in_file.eof() == false) {
        if (text == "Shape")
        {
            ++current_shape_reading;
            shape_masses.push_back(new ShapeMass(current_shape_reading));
            point_no = 0;
        }
        else if (text == ".") 
        {
            Math::vec2 position;
            in_file >> position.x;
            in_file >> position.y; // will temporarily be multiplied (NEEDS FIX)
            shape_masses.at(current_shape_reading)->AddPoint(new Point(position * 2, current_shape_reading, point_no));
            ++point_no;
        }
        else 
        {
            Engine::GetLogger().LogError("Unknown command: " + text);
        }
        in_file >> text;
    }
}

void CS230::MapManager::Unload()
{
    for (int i = 0; i < shape_masses.size(); ++i)
    {
        shape_masses[i]->~ShapeMass();
    }
    shape_masses.clear();
}

void CS230::MapManager::Draw(Math::TransformationMatrix camera_matrix)
{
    doodle::push_settings();
    doodle::set_outline_color(255,255);
    doodle::apply_matrix(
        camera_matrix[0][0],
        camera_matrix[1][0],
        camera_matrix[0][1],
        camera_matrix[1][1],
        camera_matrix[0][2],
        camera_matrix[1][2]);
    for (int i = 0; i < shape_masses.size(); ++i)
    {
        for (int j = 0; j < shape_masses[i]->GetPoints()->size(); ++j)
        {
            //doodle::draw_ellipse(   shape_masses.at(i)->GetPoints()->at(j)->GetPosition()->x,
            //                        shape_masses.at(i)->GetPoints()->at(j)->GetPosition()->y,
            //                        10, 10);
        }
        for (int j = 0; j < shape_masses[i]->GetPoints()->size() - 1; ++j)
        {
            doodle::draw_line(      shape_masses.at(i)->GetPoints()->at(j)->GetPosition()->x,
                                    shape_masses.at(i)->GetPoints()->at(j)->GetPosition()->y,
                                    shape_masses.at(i)->GetPoints()->at(j + 1)->GetPosition()->x,
                                    shape_masses.at(i)->GetPoints()->at(j + 1)->GetPosition()->y);
        }
        doodle::draw_line(          shape_masses.at(i)->GetPoints()->at(0)->GetPosition()->x,
                                    shape_masses.at(i)->GetPoints()->at(0)->GetPosition()->y,
                                    shape_masses.at(i)->GetPoints()->at(shape_masses[i]->GetPoints()->size() - 1)->GetPosition()->x,
                                    shape_masses.at(i)->GetPoints()->at(shape_masses[i]->GetPoints()->size() - 1)->GetPosition()->y);
    }
    doodle::pop_settings();
}
